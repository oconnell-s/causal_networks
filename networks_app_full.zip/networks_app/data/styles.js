var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.2",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "dce",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "content" : "",
      "font-size" : 14,
      "shape" : "diamond",
      "width" : 169.0,
      "height" : 45.0,
      "border-color" : "rgb(37,37,37)",
      "color" : "rgb(37,37,37)",
      "text-valign" : "center",
      "text-halign" : "center",
      "background-opacity" : 1.0,
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "border-width" : 5.0,
      "background-color" : "rgb(255,255,255)",
      "text-opacity" : 1.0,
      "border-opacity" : 1.0
    }
  }, {
    "selector" : "node[source_cat = 'WM tract OD']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[source_cat = 'WM tract diffusivity']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[source_cat = 'cortical grey-white contrast']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[source_cat = 'regional and tissue volume']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[source_cat = 'regional and tissue intensity']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[source_cat = 'WM tract ICVF']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Left VIIIa Cerebellum']",
    "css" : {
      "content" : "L cerebellum gmv"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Right Caudate']",
    "css" : {
      "content" : "R caudate gmv"
    }
  }, {
    "selector" : "node[shared_name = 'aseg rh intensity Pallidum']",
    "css" : {
      "content" : "R pallidum intensity"
    }
  }, {
    "selector" : "node[shared_name = 'aseg rh intensity Caudate']",
    "css" : {
      "content" : "R caudate intensity"
    }
  }, {
    "selector" : "node[shared_name = 'IDP T1 FAST ROIs L cerebellum VIIIa']",
    "css" : {
      "content" : "gmv cerebellum"
    }
  }, {
    "selector" : "node[shared_name = 'IDP T1 FIRST right caudate volume']",
    "css" : {
      "content" : "R caudate volume"
    }
  }, {
    "selector" : "node[shared_name = 'Mean L3 in superior longitudinal fasciculus (left)']",
    "css" : {
      "content" : "L slf L3"
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of Accumbens-area (right hemisphere)']",
    "css" : {
      "content" : "rh acc intensity"
    }
  }, {
    "selector" : "node[shared_name = 'IDP T1 FAST ROIs L caudate']",
    "css" : {
      "content" : "gmv L caudate"
    }
  }, {
    "selector" : "node[shared_name = 'HippSubfield lh volume Whole-hippocampal-body']",
    "css" : {
      "content" : "Volume lh hippo"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF in superior longitudinal fasciculus (right)']",
    "css" : {
      "content" : "R slf ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS MD Superior longitudinal fasciculus L']",
    "css" : {
      "content" : "MD L slf"
    }
  }, {
    "selector" : "node[shared_name = 'Mean MD in superior longitudinal fasciculus (left)']",
    "css" : {
      "content" : "L slf MD"
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of accumbens area (right hemisphere)']",
    "css" : {
      "content" : "rh acc intensity "
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of caudate (right hemisphere)']",
    "css" : {
      "content" : "rh caudate intensity"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of hippocampal body (left hemisphere)']",
    "css" : {
      "content" : "lh hippo volume"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of pons (whole brain)']",
    "css" : {
      "content" : "pons volume"
    }
  }, {
    "selector" : "node[shared_name = 'wg rh intensity-contrast paracentral']",
    "css" : {
      "content" : "paracentral contrast"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS MD Anterior limb of internal capsule L']",
    "css" : {
      "content" : "MD L int cap"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in cuneus (right hemisphere)']",
    "css" : {
      "content" : "rh cuneus c"
    }
  }, {
    "selector" : "node[shared_name = 'Weighted-mean ICVF in tract middle cerebellar peduncle']",
    "css" : {
      "content" : "tract mcp ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Body of corpus callosum']",
    "css" : {
      "content" : "ICVF corp call"
    }
  }, {
    "selector" : "node[shared_name = 'IDP T1 FAST ROIs R caudate']",
    "css" : {
      "content" : "gmv R caudate"
    }
  }, {
    "selector" : "node[shared_name = 'Mean L3 in superior longitudinal fasciculus (right)']",
    "css" : {
      "content" : "R slf L3"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF in superior cerebellar peduncle (right)']",
    "css" : {
      "content" : "R sup peduncle ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Right Thalamus']",
    "css" : {
      "content" : "R thalamus gmv"
    }
  }, {
    "selector" : "node[shared_name = 'rfMRI connectivity ICA-features 6']",
    "css" : {
      "content" : "rfMRI features 6"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS OD Cerebral peduncle L']",
    "css" : {
      "content" : "OD L cp"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in insula (right hemisphere)']",
    "css" : {
      "content" : "rh insula c"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF in cerebral peduncle (left)']",
    "css" : {
      "content" : "L peduncle ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Right Putamen']",
    "css" : {
      "content" : "R putamen gmv"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in parahippocampal (right hemisphere)']",
    "css" : {
      "content" : "rh parah c"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Left Caudate']",
    "css" : {
      "content" : "L caudate gmv"
    }
  }, {
    "selector" : "node[shared_name = 'IDP T1 FAST ROIs R thalamus']",
    "css" : {
      "content" : "gmv R thalamus"
    }
  }, {
    "selector" : "node[shared_name = 'Mean OD in cerebral peduncle (left)']",
    "css" : {
      "content" : "L peduncle OD"
    }
  }, {
    "selector" : "node[shared_name = 'wg rh intensity-contrast cuneus']",
    "css" : {
      "content" : "cuneus contrast"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF  in anterior limb of internal capsule (left)']",
    "css" : {
      "content" : "L capsule ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS OD External capsule R']",
    "css" : {
      "content" : "OD R ext cap"
    }
  }, {
    "selector" : "node[shared_name = 'BD']",
    "css" : {
      "content" : "BD"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Superior longitudinal fasciculus R']",
    "css" : {
      "content" : "ICVF R slf"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in superiorfrontal (right hemisphere)']",
    "css" : {
      "content" : "rh superiorfrontal c"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of medulla (whole brain)']",
    "css" : {
      "content" : "medulla volume"
    }
  }, {
    "selector" : "node[shared_name = 'AmygNuclei rh volume Lateral-nucleus']",
    "css" : {
      "content" : "rh volume amyg"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI ProbtrackX ICVF slf r']",
    "css" : {
      "content" : "ICVF R slf (dMRI)"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Left Putamen']",
    "css" : {
      "content" : "L putamen gmv"
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of Putamen (left hemisphere)']",
    "css" : {
      "content" : "lh putamen intensity"
    }
  }, {
    "selector" : "node[shared_name = 'Mean MD in anterior limb of internal capsule (left)']",
    "css" : {
      "content" : "L capsule MD"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI ProbtrackX ICVF slf l']",
    "css" : {
      "content" : "ICVF L slf (dMRI)"
    }
  }, {
    "selector" : "node[shared_name = 'Mean OD in external capsule (right)']",
    "css" : {
      "content" : "R ex capsule OD"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Cerebral peduncle L']",
    "css" : {
      "content" : "ICVF L cp"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Superior cerebellar peduncle R']",
    "css" : {
      "content" : "ICVF R sup cp"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Superior longitudinal fasciculus L']",
    "css" : {
      "content" : "ICVF L slf"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Posterior corona radiata R']",
    "css" : {
      "content" : "ICVF R corona radiata"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI ProbtrackX ICVF ilf r']",
    "css" : {
      "content" : "ICVF R ilf"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI ProbtrackX ICVF fmi']",
    "css" : {
      "content" : "ICVF forceps m"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of Lateral-nucleus (right hemisphere)']",
    "css" : {
      "content" : "lat nuc volume"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of right caudate (from T1 brain image)']",
    "css" : {
      "content" : "R caudate volume"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF in anterior limb of internal capsule (left)']",
    "css" : {
      "content" : "L capsule ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI ProbtrackX ICVF mcp']",
    "css" : {
      "content" : "ICVF mcp"
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of Caudate (right hemisphere)']",
    "css" : {
      "content" : "rh caudate intensity"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of hippocampal body (whole brain)']",
    "css" : {
      "content" : "Hippo volume"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of VentralDC (right hemisphere)']",
    "css" : {
      "content" : "rh VDC volume "
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in superiortemporal (left hemisphere)']",
    "css" : {
      "content" : "lh superiortemporal c"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in paracentral (right hemisphere)']",
    "css" : {
      "content" : "rh parac c"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of brainstem (whole brain)']",
    "css" : {
      "content" : "brainstem volume"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in superiorfrontal (left hemisphere)']",
    "css" : {
      "content" : "lh superiorfrontal c"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of Pons (whole brain)']",
    "css" : {
      "content" : "pons volume"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of Medulla (whole brain)']",
    "css" : {
      "content" : "medulla volume"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of amygdala lateral nuclei (right hemisphere)']",
    "css" : {
      "content" : "R lat nuc volume"
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of putamen (left hemisphere)']",
    "css" : {
      "content" : "lh caudate intensity"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF in anterior limb of internal capsule (right)']",
    "css" : {
      "content" : "R capsule ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'wg rh intensity-contrast parahippocampal']",
    "css" : {
      "content" : "parahippo contrast"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "color" : "rgb(11,59,59)",
      "line-color" : "rgb(204,204,204)",
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-color" : "rgb(204,204,204)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "target-arrow-shape" : "triangle",
      "content" : "",
      "width" : 5.0,
      "source-arrow-color" : "rgb(204,204,204)",
      "opacity" : 1.0,
      "font-size" : 12
    }
  }, {
    "selector" : "edge[sign = -1]",
    "css" : {
      "line-color" : "rgb(0,0,255)",
      "target-arrow-color" : "rgb(0,0,255)",
      "source-arrow-color" : "rgb(0,0,255)"
    }
  }, {
    "selector" : "edge[sign = 1]",
    "css" : {
      "line-color" : "rgb(255,0,0)",
      "target-arrow-color" : "rgb(255,0,0)",
      "source-arrow-color" : "rgb(255,0,0)"
    }
  }, {
    "selector" : "edge[abs_weight > 0.05319555]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[abs_weight = 0.05319555]",
    "css" : {
      "width" : 9.181947708129883
    }
  }, {
    "selector" : "edge[abs_weight > 0.0148912][abs_weight < 0.05319555]",
    "css" : {
      "width" : "mapData(abs_weight,0.0148912,0.05319555,0.16760114440344331,9.181947708129883)"
    }
  }, {
    "selector" : "edge[abs_weight = 0.0148912]",
    "css" : {
      "width" : 0.16760114440344331
    }
  }, {
    "selector" : "edge[abs_weight < 0.0148912]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.2",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "rg",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "content" : "",
      "font-size" : 14,
      "shape" : "diamond",
      "width" : 169.0,
      "height" : 45.0,
      "border-color" : "rgb(37,37,37)",
      "color" : "rgb(37,37,37)",
      "text-valign" : "center",
      "text-halign" : "center",
      "background-opacity" : 1.0,
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "border-width" : 5.0,
      "background-color" : "rgb(255,255,255)",
      "text-opacity" : 1.0,
      "border-opacity" : 1.0
    }
  }, {
    "selector" : "node[source_cat = 'WM tract OD']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[source_cat = 'WM tract diffusivity']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[source_cat = 'cortical grey-white contrast']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[source_cat = 'regional and tissue volume']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[source_cat = 'regional and tissue intensity']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[source_cat = 'WM tract ICVF']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Left VIIIa Cerebellum']",
    "css" : {
      "content" : "L cerebellum gmv"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Right Caudate']",
    "css" : {
      "content" : "R caudate gmv"
    }
  }, {
    "selector" : "node[shared_name = 'aseg rh intensity Pallidum']",
    "css" : {
      "content" : "R pallidum intensity"
    }
  }, {
    "selector" : "node[shared_name = 'aseg rh intensity Caudate']",
    "css" : {
      "content" : "R caudate intensity"
    }
  }, {
    "selector" : "node[shared_name = 'IDP T1 FAST ROIs L cerebellum VIIIa']",
    "css" : {
      "content" : "gmv cerebellum"
    }
  }, {
    "selector" : "node[shared_name = 'IDP T1 FIRST right caudate volume']",
    "css" : {
      "content" : "R caudate volume"
    }
  }, {
    "selector" : "node[shared_name = 'Mean L3 in superior longitudinal fasciculus (left)']",
    "css" : {
      "content" : "L slf L3"
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of Accumbens-area (right hemisphere)']",
    "css" : {
      "content" : "rh acc intensity"
    }
  }, {
    "selector" : "node[shared_name = 'IDP T1 FAST ROIs L caudate']",
    "css" : {
      "content" : "gmv L caudate"
    }
  }, {
    "selector" : "node[shared_name = 'HippSubfield lh volume Whole-hippocampal-body']",
    "css" : {
      "content" : "Volume lh hippo"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF in superior longitudinal fasciculus (right)']",
    "css" : {
      "content" : "R slf ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS MD Superior longitudinal fasciculus L']",
    "css" : {
      "content" : "MD L slf"
    }
  }, {
    "selector" : "node[shared_name = 'Mean MD in superior longitudinal fasciculus (left)']",
    "css" : {
      "content" : "L slf MD"
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of accumbens area (right hemisphere)']",
    "css" : {
      "content" : "rh acc intensity "
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of caudate (right hemisphere)']",
    "css" : {
      "content" : "rh caudate intensity"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of hippocampal body (left hemisphere)']",
    "css" : {
      "content" : "lh hippo volume"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of pons (whole brain)']",
    "css" : {
      "content" : "pons volume"
    }
  }, {
    "selector" : "node[shared_name = 'wg rh intensity-contrast paracentral']",
    "css" : {
      "content" : "paracentral contrast"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS MD Anterior limb of internal capsule L']",
    "css" : {
      "content" : "MD L int cap"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in cuneus (right hemisphere)']",
    "css" : {
      "content" : "rh cuneus c"
    }
  }, {
    "selector" : "node[shared_name = 'Weighted-mean ICVF in tract middle cerebellar peduncle']",
    "css" : {
      "content" : "tract mcp ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Body of corpus callosum']",
    "css" : {
      "content" : "ICVF corp call"
    }
  }, {
    "selector" : "node[shared_name = 'IDP T1 FAST ROIs R caudate']",
    "css" : {
      "content" : "gmv R caudate"
    }
  }, {
    "selector" : "node[shared_name = 'Mean L3 in superior longitudinal fasciculus (right)']",
    "css" : {
      "content" : "R slf L3"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF in superior cerebellar peduncle (right)']",
    "css" : {
      "content" : "R sup peduncle ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Right Thalamus']",
    "css" : {
      "content" : "R thalamus gmv"
    }
  }, {
    "selector" : "node[shared_name = 'rfMRI connectivity ICA-features 6']",
    "css" : {
      "content" : "rfMRI features 6"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS OD Cerebral peduncle L']",
    "css" : {
      "content" : "OD L cp"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in insula (right hemisphere)']",
    "css" : {
      "content" : "rh insula c"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF in cerebral peduncle (left)']",
    "css" : {
      "content" : "L peduncle ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Right Putamen']",
    "css" : {
      "content" : "R putamen gmv"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in parahippocampal (right hemisphere)']",
    "css" : {
      "content" : "rh parah c"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Left Caudate']",
    "css" : {
      "content" : "L caudate gmv"
    }
  }, {
    "selector" : "node[shared_name = 'IDP T1 FAST ROIs R thalamus']",
    "css" : {
      "content" : "gmv R thalamus"
    }
  }, {
    "selector" : "node[shared_name = 'Mean OD in cerebral peduncle (left)']",
    "css" : {
      "content" : "L peduncle OD"
    }
  }, {
    "selector" : "node[shared_name = 'wg rh intensity-contrast cuneus']",
    "css" : {
      "content" : "cuneus contrast"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF  in anterior limb of internal capsule (left)']",
    "css" : {
      "content" : "L capsule ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS OD External capsule R']",
    "css" : {
      "content" : "OD R ext cap"
    }
  }, {
    "selector" : "node[shared_name = 'BD']",
    "css" : {
      "content" : "BD"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Superior longitudinal fasciculus R']",
    "css" : {
      "content" : "ICVF R slf"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in superiorfrontal (right hemisphere)']",
    "css" : {
      "content" : "rh superiorfrontal c"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of medulla (whole brain)']",
    "css" : {
      "content" : "medulla volume"
    }
  }, {
    "selector" : "node[shared_name = 'AmygNuclei rh volume Lateral-nucleus']",
    "css" : {
      "content" : "rh volume amyg"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI ProbtrackX ICVF slf r']",
    "css" : {
      "content" : "ICVF R slf (dMRI)"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Left Putamen']",
    "css" : {
      "content" : "L putamen gmv"
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of Putamen (left hemisphere)']",
    "css" : {
      "content" : "lh putamen intensity"
    }
  }, {
    "selector" : "node[shared_name = 'Mean MD in anterior limb of internal capsule (left)']",
    "css" : {
      "content" : "L capsule MD"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI ProbtrackX ICVF slf l']",
    "css" : {
      "content" : "ICVF L slf (dMRI)"
    }
  }, {
    "selector" : "node[shared_name = 'Mean OD in external capsule (right)']",
    "css" : {
      "content" : "R ex capsule OD"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Cerebral peduncle L']",
    "css" : {
      "content" : "ICVF L cp"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Superior cerebellar peduncle R']",
    "css" : {
      "content" : "ICVF R sup cp"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Superior longitudinal fasciculus L']",
    "css" : {
      "content" : "ICVF L slf"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Posterior corona radiata R']",
    "css" : {
      "content" : "ICVF R corona radiata"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI ProbtrackX ICVF ilf r']",
    "css" : {
      "content" : "ICVF R ilf"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI ProbtrackX ICVF fmi']",
    "css" : {
      "content" : "ICVF forceps m"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of Lateral-nucleus (right hemisphere)']",
    "css" : {
      "content" : "lat nuc volume"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of right caudate (from T1 brain image)']",
    "css" : {
      "content" : "R caudate volume"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF in anterior limb of internal capsule (left)']",
    "css" : {
      "content" : "L capsule ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI ProbtrackX ICVF mcp']",
    "css" : {
      "content" : "ICVF mcp"
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of Caudate (right hemisphere)']",
    "css" : {
      "content" : "rh caudate intensity"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of hippocampal body (whole brain)']",
    "css" : {
      "content" : "Hippo volume"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of VentralDC (right hemisphere)']",
    "css" : {
      "content" : "rh VDC volume "
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in superiortemporal (left hemisphere)']",
    "css" : {
      "content" : "lh superiortemporal c"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in paracentral (right hemisphere)']",
    "css" : {
      "content" : "rh parac c"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of brainstem (whole brain)']",
    "css" : {
      "content" : "brainstem volume"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in superiorfrontal (left hemisphere)']",
    "css" : {
      "content" : "lh superiorfrontal c"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of Pons (whole brain)']",
    "css" : {
      "content" : "pons volume"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of Medulla (whole brain)']",
    "css" : {
      "content" : "medulla volume"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of amygdala lateral nuclei (right hemisphere)']",
    "css" : {
      "content" : "R lat nuc volume"
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of putamen (left hemisphere)']",
    "css" : {
      "content" : "lh caudate intensity"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF in anterior limb of internal capsule (right)']",
    "css" : {
      "content" : "R capsule ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'wg rh intensity-contrast parahippocampal']",
    "css" : {
      "content" : "parahippo contrast"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "color" : "rgb(11,59,59)",
      "line-color" : "rgb(204,204,204)",
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-color" : "rgb(204,204,204)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "target-arrow-shape" : "none",
      "content" : "",
      "width" : 5.0,
      "source-arrow-color" : "rgb(204,204,204)",
      "opacity" : 1.0,
      "font-size" : 12
    }
  }, {
    "selector" : "edge[rg_sign = -1]",
    "css" : {
      "line-color" : "rgb(73,73,255)",
      "target-arrow-color" : "rgb(73,73,255)",
      "source-arrow-color" : "rgb(73,73,255)"
    }
  }, {
    "selector" : "edge[rg_sign = 1]",
    "css" : {
      "line-color" : "rgb(255,0,0)",
      "target-arrow-color" : "rgb(255,0,0)",
      "source-arrow-color" : "rgb(255,0,0)"
    }
  }, {
    "selector" : "edge[abs_rg > 0.05319555]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[abs_rg = 0.05319555]",
    "css" : {
      "width" : 9.181947708129883
    }
  }, {
    "selector" : "edge[abs_rg > 0.0148912][abs_rg < 0.05319555]",
    "css" : {
      "width" : "mapData(abs_rg,0.0148912,0.05319555,0.16760114440344331,9.181947708129883)"
    }
  }, {
    "selector" : "edge[abs_rg = 0.0148912]",
    "css" : {
      "width" : 0.16760114440344331
    }
  }, {
    "selector" : "edge[abs_rg < 0.0148912]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.2",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "tce",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "content" : "",
      "font-size" : 14,
      "shape" : "diamond",
      "width" : 169.0,
      "height" : 45.0,
      "border-color" : "rgb(37,37,37)",
      "color" : "rgb(37,37,37)",
      "text-valign" : "center",
      "text-halign" : "center",
      "background-opacity" : 1.0,
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "border-width" : 5.0,
      "background-color" : "rgb(255,255,255)",
      "text-opacity" : 1.0,
      "border-opacity" : 1.0
    }
  }, {
    "selector" : "node[source_cat = 'WM tract OD']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[source_cat = 'WM tract diffusivity']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[source_cat = 'cortical grey-white contrast']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[source_cat = 'regional and tissue volume']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[source_cat = 'regional and tissue intensity']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[source_cat = 'WM tract ICVF']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Left VIIIa Cerebellum']",
    "css" : {
      "content" : "L cerebellum gmv"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Right Caudate']",
    "css" : {
      "content" : "R caudate gmv"
    }
  }, {
    "selector" : "node[shared_name = 'aseg rh intensity Pallidum']",
    "css" : {
      "content" : "R pallidum intensity"
    }
  }, {
    "selector" : "node[shared_name = 'aseg rh intensity Caudate']",
    "css" : {
      "content" : "R caudate intensity"
    }
  }, {
    "selector" : "node[shared_name = 'IDP T1 FAST ROIs L cerebellum VIIIa']",
    "css" : {
      "content" : "gmv cerebellum"
    }
  }, {
    "selector" : "node[shared_name = 'IDP T1 FIRST right caudate volume']",
    "css" : {
      "content" : "R caudate volume"
    }
  }, {
    "selector" : "node[shared_name = 'Mean L3 in superior longitudinal fasciculus (left)']",
    "css" : {
      "content" : "L slf L3"
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of Accumbens-area (right hemisphere)']",
    "css" : {
      "content" : "rh acc intensity"
    }
  }, {
    "selector" : "node[shared_name = 'IDP T1 FAST ROIs L caudate']",
    "css" : {
      "content" : "gmv L caudate"
    }
  }, {
    "selector" : "node[shared_name = 'HippSubfield lh volume Whole-hippocampal-body']",
    "css" : {
      "content" : "Volume lh hippo"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF in superior longitudinal fasciculus (right)']",
    "css" : {
      "content" : "R slf ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS MD Superior longitudinal fasciculus L']",
    "css" : {
      "content" : "MD L slf"
    }
  }, {
    "selector" : "node[shared_name = 'Mean MD in superior longitudinal fasciculus (left)']",
    "css" : {
      "content" : "L slf MD"
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of accumbens area (right hemisphere)']",
    "css" : {
      "content" : "rh acc intensity "
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of caudate (right hemisphere)']",
    "css" : {
      "content" : "rh caudate intensity"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of hippocampal body (left hemisphere)']",
    "css" : {
      "content" : "lh hippo volume"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of pons (whole brain)']",
    "css" : {
      "content" : "pons volume"
    }
  }, {
    "selector" : "node[shared_name = 'wg rh intensity-contrast paracentral']",
    "css" : {
      "content" : "paracentral contrast"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS MD Anterior limb of internal capsule L']",
    "css" : {
      "content" : "MD L int cap"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in cuneus (right hemisphere)']",
    "css" : {
      "content" : "rh cuneus c"
    }
  }, {
    "selector" : "node[shared_name = 'Weighted-mean ICVF in tract middle cerebellar peduncle']",
    "css" : {
      "content" : "tract mcp ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Body of corpus callosum']",
    "css" : {
      "content" : "ICVF corp call"
    }
  }, {
    "selector" : "node[shared_name = 'IDP T1 FAST ROIs R caudate']",
    "css" : {
      "content" : "gmv R caudate"
    }
  }, {
    "selector" : "node[shared_name = 'Mean L3 in superior longitudinal fasciculus (right)']",
    "css" : {
      "content" : "R slf L3"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF in superior cerebellar peduncle (right)']",
    "css" : {
      "content" : "R sup peduncle ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Right Thalamus']",
    "css" : {
      "content" : "R thalamus gmv"
    }
  }, {
    "selector" : "node[shared_name = 'rfMRI connectivity ICA-features 6']",
    "css" : {
      "content" : "rfMRI features 6"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS OD Cerebral peduncle L']",
    "css" : {
      "content" : "OD L cp"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in insula (right hemisphere)']",
    "css" : {
      "content" : "rh insula c"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF in cerebral peduncle (left)']",
    "css" : {
      "content" : "L peduncle ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Right Putamen']",
    "css" : {
      "content" : "R putamen gmv"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in parahippocampal (right hemisphere)']",
    "css" : {
      "content" : "rh parah c"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Left Caudate']",
    "css" : {
      "content" : "L caudate gmv"
    }
  }, {
    "selector" : "node[shared_name = 'IDP T1 FAST ROIs R thalamus']",
    "css" : {
      "content" : "gmv R thalamus"
    }
  }, {
    "selector" : "node[shared_name = 'Mean OD in cerebral peduncle (left)']",
    "css" : {
      "content" : "L peduncle OD"
    }
  }, {
    "selector" : "node[shared_name = 'wg rh intensity-contrast cuneus']",
    "css" : {
      "content" : "cuneus contrast"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF  in anterior limb of internal capsule (left)']",
    "css" : {
      "content" : "L capsule ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS OD External capsule R']",
    "css" : {
      "content" : "OD R ext cap"
    }
  }, {
    "selector" : "node[shared_name = 'BD']",
    "css" : {
      "content" : "BD"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Superior longitudinal fasciculus R']",
    "css" : {
      "content" : "ICVF R slf"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in superiorfrontal (right hemisphere)']",
    "css" : {
      "content" : "rh superiorfrontal c"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of medulla (whole brain)']",
    "css" : {
      "content" : "medulla volume"
    }
  }, {
    "selector" : "node[shared_name = 'AmygNuclei rh volume Lateral-nucleus']",
    "css" : {
      "content" : "rh volume amyg"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI ProbtrackX ICVF slf r']",
    "css" : {
      "content" : "ICVF R slf (dMRI)"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of grey matter in Left Putamen']",
    "css" : {
      "content" : "L putamen gmv"
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of Putamen (left hemisphere)']",
    "css" : {
      "content" : "lh putamen intensity"
    }
  }, {
    "selector" : "node[shared_name = 'Mean MD in anterior limb of internal capsule (left)']",
    "css" : {
      "content" : "L capsule MD"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI ProbtrackX ICVF slf l']",
    "css" : {
      "content" : "ICVF L slf (dMRI)"
    }
  }, {
    "selector" : "node[shared_name = 'Mean OD in external capsule (right)']",
    "css" : {
      "content" : "R ex capsule OD"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Cerebral peduncle L']",
    "css" : {
      "content" : "ICVF L cp"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Superior cerebellar peduncle R']",
    "css" : {
      "content" : "ICVF R sup cp"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Superior longitudinal fasciculus L']",
    "css" : {
      "content" : "ICVF L slf"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI TBSS ICVF Posterior corona radiata R']",
    "css" : {
      "content" : "ICVF R corona radiata"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI ProbtrackX ICVF ilf r']",
    "css" : {
      "content" : "ICVF R ilf"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI ProbtrackX ICVF fmi']",
    "css" : {
      "content" : "ICVF forceps m"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of Lateral-nucleus (right hemisphere)']",
    "css" : {
      "content" : "lat nuc volume"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of right caudate (from T1 brain image)']",
    "css" : {
      "content" : "R caudate volume"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF in anterior limb of internal capsule (left)']",
    "css" : {
      "content" : "L capsule ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'IDP dMRI ProbtrackX ICVF mcp']",
    "css" : {
      "content" : "ICVF mcp"
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of Caudate (right hemisphere)']",
    "css" : {
      "content" : "rh caudate intensity"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of hippocampal body (whole brain)']",
    "css" : {
      "content" : "Hippo volume"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of VentralDC (right hemisphere)']",
    "css" : {
      "content" : "rh VDC volume "
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in superiortemporal (left hemisphere)']",
    "css" : {
      "content" : "lh superiortemporal c"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in paracentral (right hemisphere)']",
    "css" : {
      "content" : "rh parac c"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of brainstem (whole brain)']",
    "css" : {
      "content" : "brainstem volume"
    }
  }, {
    "selector" : "node[shared_name = 'GW contrast in superiorfrontal (left hemisphere)']",
    "css" : {
      "content" : "lh superiorfrontal c"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of Pons (whole brain)']",
    "css" : {
      "content" : "pons volume"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of Medulla (whole brain)']",
    "css" : {
      "content" : "medulla volume"
    }
  }, {
    "selector" : "node[shared_name = 'Volume of amygdala lateral nuclei (right hemisphere)']",
    "css" : {
      "content" : "R lat nuc volume"
    }
  }, {
    "selector" : "node[shared_name = 'Mean intensity of putamen (left hemisphere)']",
    "css" : {
      "content" : "lh caudate intensity"
    }
  }, {
    "selector" : "node[shared_name = 'Mean ICVF in anterior limb of internal capsule (right)']",
    "css" : {
      "content" : "R capsule ICVF"
    }
  }, {
    "selector" : "node[shared_name = 'wg rh intensity-contrast parahippocampal']",
    "css" : {
      "content" : "parahippo contrast"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "color" : "rgb(11,59,59)",
      "line-color" : "rgb(204,204,204)",
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-color" : "rgb(204,204,204)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "target-arrow-shape" : "triangle",
      "content" : "",
      "width" : 5.0,
      "source-arrow-color" : "rgb(204,204,204)",
      "opacity" : 1.0,
      "font-size" : 12
    }
  }, {
    "selector" : "edge[sign_tce = -1]",
    "css" : {
      "line-color" : "rgb(0,0,255)",
      "target-arrow-color" : "rgb(0,0,255)",
      "source-arrow-color" : "rgb(0,0,255)"
    }
  }, {
    "selector" : "edge[sign_tce = 1]",
    "css" : {
      "line-color" : "rgb(255,0,0)",
      "target-arrow-color" : "rgb(255,0,0)",
      "source-arrow-color" : "rgb(255,0,0)"
    }
  }, {
    "selector" : "edge[abs_tce_weight > 0.05319555]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[abs_tce_weight = 0.05319555]",
    "css" : {
      "width" : 9.181947708129883
    }
  }, {
    "selector" : "edge[abs_tce_weight > 0.0148912][abs_tce_weight < 0.05319555]",
    "css" : {
      "width" : "mapData(abs_tce_weight,0.0148912,0.05319555,0.16760114440344331,9.181947708129883)"
    }
  }, {
    "selector" : "edge[abs_tce_weight = 0.0148912]",
    "css" : {
      "width" : 0.16760114440344331
    }
  }, {
    "selector" : "edge[abs_tce_weight < 0.0148912]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]
