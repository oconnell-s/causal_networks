var networks = {"DCE sparse network": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.2",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "DCE sparse network",
    "name" : "DCE sparse network",
    "SUID" : 29769,
    "__Annotations" : [ ],
    "selected" : false
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "3410",
        "shared_name" : "IDP dMRI TBSS ICVF Body of corpus callosum",
        "name" : "IDP dMRI TBSS ICVF Body of corpus callosum",
        "SUID" : 3410,
        "selected" : false,
        "source_cat" : "WM tract ICVF"
      },
      "position" : {
        "x" : 94.48888680220578,
        "y" : 6.394990249996754
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1293",
        "shared_name" : "BD",
        "name" : "BD",
        "degree_layout" : 9,
        "SUID" : 1293,
        "selected" : false,
        "source_cat" : "BD"
      },
      "position" : {
        "x" : -1.1430468784423873,
        "y" : 169.4003652410016
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3146",
        "shared_name" : "IDP dMRI ProbtrackX ICVF ilf r",
        "name" : "IDP dMRI ProbtrackX ICVF ilf r",
        "SUID" : 3146,
        "selected" : false,
        "source_cat" : "WM tract ICVF"
      },
      "position" : {
        "x" : 255.30354052760342,
        "y" : 33.18738747386819
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3342",
        "shared_name" : "IDP dMRI ProbtrackX ICVF fmi",
        "name" : "IDP dMRI ProbtrackX ICVF fmi",
        "SUID" : 3342,
        "selected" : false,
        "source_cat" : "WM tract ICVF"
      },
      "position" : {
        "x" : -9.04760323632027,
        "y" : -143.12424275339586
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3174",
        "shared_name" : "IDP dMRI TBSS ICVF Superior longitudinal fasciculus L",
        "name" : "IDP dMRI TBSS ICVF Superior longitudinal fasciculus L",
        "SUID" : 3174,
        "selected" : false,
        "source_cat" : "WM tract ICVF"
      },
      "position" : {
        "x" : -273.39874700024393,
        "y" : -3.164923908798179
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3172",
        "shared_name" : "IDP dMRI ProbtrackX ICVF slf r",
        "name" : "IDP dMRI ProbtrackX ICVF slf r",
        "SUID" : 3172,
        "selected" : false,
        "source_cat" : "WM tract ICVF"
      },
      "position" : {
        "x" : -250.96649636125943,
        "y" : -92.59096397530948
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3502",
        "shared_name" : "IDP dMRI TBSS ICVF Superior longitudinal fasciculus R",
        "name" : "IDP dMRI TBSS ICVF Superior longitudinal fasciculus R",
        "SUID" : 3502,
        "selected" : false,
        "source_cat" : "WM tract ICVF"
      },
      "position" : {
        "x" : -130.4285066667166,
        "y" : 45.05689066066127
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "29817",
        "source" : "3410",
        "target" : "1293",
        "abs_rg" : 0.0355965455813031,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0123366447772245,
        "abs_weight" : 0.0123366447772245,
        "shared_name" : "IDP dMRI TBSS ICVF Body of corpus callosum (interacts with) BD",
        "rg" : -0.0355965455813031,
        "source_cat" : "",
        "tce" : -0.0977853282967574,
        "name" : "IDP dMRI TBSS ICVF Body of corpus callosum (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 29817,
        "rg_sign" : -1,
        "abs_tce_weight" : 0.0977853282967574,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "29815",
        "source" : "3146",
        "target" : "1293",
        "abs_rg" : 0.0601431018330982,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0075473326403331,
        "abs_weight" : 0.0075473326403331,
        "shared_name" : "IDP dMRI ProbtrackX ICVF ilf r (interacts with) BD",
        "rg" : -0.0601431018330982,
        "source_cat" : "",
        "tce" : -0.0811427100499107,
        "name" : "IDP dMRI ProbtrackX ICVF ilf r (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 29815,
        "rg_sign" : -1,
        "abs_tce_weight" : 0.0811427100499107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "29813",
        "source" : "3342",
        "target" : "3410",
        "abs_rg" : 0.9116031204915808,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : -1,
        "weight" : -0.0531507536627711,
        "abs_weight" : 0.0531507536627711,
        "shared_name" : "IDP dMRI ProbtrackX ICVF fmi (interacts with) IDP dMRI TBSS ICVF Body of corpus callosum",
        "rg" : 0.9116031204915808,
        "source_cat" : "",
        "tce" : 0.857617498611464,
        "name" : "IDP dMRI ProbtrackX ICVF fmi (interacts with) IDP dMRI TBSS ICVF Body of corpus callosum",
        "interaction" : "interacts with",
        "SUID" : 29813,
        "rg_sign" : 1,
        "abs_tce_weight" : 0.857617498611464,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "29811",
        "source" : "3342",
        "target" : "3146",
        "abs_rg" : 0.8799552600391803,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : -1,
        "weight" : -0.0256833140088798,
        "abs_weight" : 0.0256833140088798,
        "shared_name" : "IDP dMRI ProbtrackX ICVF fmi (interacts with) IDP dMRI ProbtrackX ICVF ilf r",
        "rg" : 0.8799552600391803,
        "source_cat" : "",
        "tce" : 0.79845273224675,
        "name" : "IDP dMRI ProbtrackX ICVF fmi (interacts with) IDP dMRI ProbtrackX ICVF ilf r",
        "interaction" : "interacts with",
        "SUID" : 29811,
        "rg_sign" : 1,
        "abs_tce_weight" : 0.79845273224675,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "29809",
        "source" : "3342",
        "target" : "3174",
        "abs_rg" : 0.8932987977129553,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : -1,
        "weight" : -0.0108522774554889,
        "abs_weight" : 0.0108522774554889,
        "shared_name" : "IDP dMRI ProbtrackX ICVF fmi (interacts with) IDP dMRI TBSS ICVF Superior longitudinal fasciculus L",
        "rg" : 0.8932987977129553,
        "source_cat" : "",
        "tce" : 0.748331204335899,
        "name" : "IDP dMRI ProbtrackX ICVF fmi (interacts with) IDP dMRI TBSS ICVF Superior longitudinal fasciculus L",
        "interaction" : "interacts with",
        "SUID" : 29809,
        "rg_sign" : 1,
        "abs_tce_weight" : 0.748331204335899,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "29807",
        "source" : "3342",
        "target" : "3172",
        "abs_rg" : 0.8978917620845711,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : -1,
        "weight" : -0.0120112101853022,
        "abs_weight" : 0.0120112101853022,
        "shared_name" : "IDP dMRI ProbtrackX ICVF fmi (interacts with) IDP dMRI ProbtrackX ICVF slf r",
        "rg" : 0.8978917620845711,
        "source_cat" : "",
        "tce" : 0.764056170612889,
        "name" : "IDP dMRI ProbtrackX ICVF fmi (interacts with) IDP dMRI ProbtrackX ICVF slf r",
        "interaction" : "interacts with",
        "SUID" : 29807,
        "rg_sign" : 1,
        "abs_tce_weight" : 0.764056170612889,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "29805",
        "source" : "3342",
        "target" : "3502",
        "abs_rg" : 0.8842168707664728,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : -1,
        "weight" : -0.007075689338794,
        "abs_weight" : 0.007075689338794,
        "shared_name" : "IDP dMRI ProbtrackX ICVF fmi (interacts with) IDP dMRI TBSS ICVF Superior longitudinal fasciculus R",
        "rg" : 0.8842168707664728,
        "source_cat" : "",
        "tce" : 0.767686247273353,
        "name" : "IDP dMRI ProbtrackX ICVF fmi (interacts with) IDP dMRI TBSS ICVF Superior longitudinal fasciculus R",
        "interaction" : "interacts with",
        "SUID" : 29805,
        "rg_sign" : 1,
        "abs_tce_weight" : 0.767686247273353,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "29803",
        "source" : "3342",
        "target" : "1293",
        "abs_rg" : 0.0471934786529359,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0063705470719247,
        "abs_weight" : 0.0063705470719247,
        "shared_name" : "IDP dMRI ProbtrackX ICVF fmi (interacts with) BD",
        "rg" : -0.0471934786529359,
        "source_cat" : "",
        "tce" : -0.029312366029747,
        "name" : "IDP dMRI ProbtrackX ICVF fmi (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 29803,
        "rg_sign" : -1,
        "abs_tce_weight" : 0.029312366029747,
        "selected" : false
      },
      "selected" : false
    } ]
  }
},"DCE dense network (top 20 exposures acting on BD)": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.2",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "DCE dense network (top 20 exposures acting on BD)",
    "name" : "DCE dense network (top 20 exposures acting on BD)",
    "SUID" : 864,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "222",
        "shared_name" : "IDP T1 FAST ROIs R caudate",
        "name" : "IDP T1 FAST ROIs R caudate",
        "SUID" : 222,
        "selected" : false,
        "source_cat" : "regional and tissue volume"
      },
      "position" : {
        "x" : 231.38069877054332,
        "y" : 347.0288316573927
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "216",
        "shared_name" : "IDP T1 FAST ROIs L caudate",
        "name" : "IDP T1 FAST ROIs L caudate",
        "SUID" : 216,
        "selected" : false,
        "source_cat" : "regional and tissue volume"
      },
      "position" : {
        "x" : 231.38069877054332,
        "y" : -42.83205113365756
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "214",
        "shared_name" : "IDP dMRI TBSS MD Superior longitudinal fasciculus L",
        "name" : "IDP dMRI TBSS MD Superior longitudinal fasciculus L",
        "SUID" : 214,
        "selected" : false,
        "source_cat" : "WM tract diffusivity"
      },
      "position" : {
        "x" : -366.6989609474796,
        "y" : 322.9953007628652
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "212",
        "shared_name" : "wg rh intensity-contrast cuneus",
        "name" : "wg rh intensity-contrast cuneus",
        "SUID" : 212,
        "selected" : false,
        "source_cat" : "cortical grey-white contrast"
      },
      "position" : {
        "x" : 231.38069877054332,
        "y" : 282.0520178588916
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "200",
        "shared_name" : "IDP dMRI TBSS ICVF Posterior corona radiata R",
        "name" : "IDP dMRI TBSS ICVF Posterior corona radiata R",
        "SUID" : 200,
        "selected" : false,
        "source_cat" : "WM tract ICVF"
      },
      "position" : {
        "x" : -366.6989609474796,
        "y" : -195.00732367276157
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "198",
        "shared_name" : "IDP T1 FIRST right caudate volume",
        "name" : "IDP T1 FIRST right caudate volume",
        "SUID" : 198,
        "selected" : false,
        "source_cat" : "regional and tissue volume"
      },
      "position" : {
        "x" : 231.38069877054332,
        "y" : 22.14476266484354
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "188",
        "shared_name" : "BD",
        "name" : "BD",
        "SUID" : 188,
        "selected" : false,
        "source_cat" : "BD"
      },
      "position" : {
        "x" : -84.79268926286767,
        "y" : 476.56892419878875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "220",
        "shared_name" : "IDP dMRI TBSS MD Anterior limb of internal capsule L",
        "name" : "IDP dMRI TBSS MD Anterior limb of internal capsule L",
        "SUID" : 220,
        "selected" : false,
        "source_cat" : "WM tract diffusivity"
      },
      "position" : {
        "x" : -366.6989609474796,
        "y" : -22.339782194212034
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "210",
        "shared_name" : "IDP dMRI TBSS OD External capsule R",
        "name" : "IDP dMRI TBSS OD External capsule R",
        "SUID" : 210,
        "selected" : false,
        "source_cat" : "WM tract OD"
      },
      "position" : {
        "x" : -366.6989609474796,
        "y" : -108.67355293349772
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "192",
        "shared_name" : "wg rh intensity-contrast parahippocampal",
        "name" : "wg rh intensity-contrast parahippocampal",
        "SUID" : 192,
        "selected" : false,
        "source_cat" : "cortical grey-white contrast"
      },
      "position" : {
        "x" : 231.38069877054332,
        "y" : 87.12157646336647
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "218",
        "shared_name" : "IDP dMRI TBSS ICVF Superior cerebellar peduncle R",
        "name" : "IDP dMRI TBSS ICVF Superior cerebellar peduncle R",
        "SUID" : 218,
        "selected" : false,
        "source_cat" : "WM tract ICVF"
      },
      "position" : {
        "x" : -366.6989609474796,
        "y" : 63.993988545044544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "194",
        "shared_name" : "IDP dMRI TBSS ICVF Cerebral peduncle L",
        "name" : "IDP dMRI TBSS ICVF Cerebral peduncle L",
        "SUID" : 194,
        "selected" : false,
        "source_cat" : "WM tract ICVF"
      },
      "position" : {
        "x" : -366.6989609474796,
        "y" : 150.32775928434478
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "186",
        "shared_name" : "AmygNuclei rh volume Lateral-nucleus",
        "name" : "AmygNuclei rh volume Lateral-nucleus",
        "SUID" : 186,
        "selected" : false,
        "source_cat" : "regional and tissue volume"
      },
      "position" : {
        "x" : 231.38069877054332,
        "y" : -107.80886493217321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "196",
        "shared_name" : "HippSubfield lh volume Whole-hippocampal-body",
        "name" : "HippSubfield lh volume Whole-hippocampal-body",
        "SUID" : 196,
        "selected" : false,
        "source_cat" : "regional and tissue volume"
      },
      "position" : {
        "x" : 231.38069877054332,
        "y" : 412.00564545593016
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "184",
        "shared_name" : "IDP T1 FAST ROIs L cerebellum VIIIa",
        "name" : "IDP T1 FAST ROIs L cerebellum VIIIa",
        "SUID" : 184,
        "selected" : false,
        "source_cat" : "regional and tissue volume"
      },
      "position" : {
        "x" : 231.38069877054332,
        "y" : 152.09839026188212
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "204",
        "shared_name" : "aseg rh intensity Caudate",
        "name" : "aseg rh intensity Caudate",
        "SUID" : 204,
        "selected" : false,
        "source_cat" : "regional and tissue intensity"
      },
      "position" : {
        "x" : 231.38069877054332,
        "y" : 217.07520406037594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "202",
        "shared_name" : "wg rh intensity-contrast paracentral",
        "name" : "wg rh intensity-contrast paracentral",
        "SUID" : 202,
        "selected" : false,
        "source_cat" : "cortical grey-white contrast"
      },
      "position" : {
        "x" : 231.38069877054332,
        "y" : 476.98245925443126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "182",
        "shared_name" : "IDP dMRI TBSS OD Cerebral peduncle L",
        "name" : "IDP dMRI TBSS OD Cerebral peduncle L",
        "SUID" : 182,
        "selected" : false,
        "source_cat" : "WM tract OD"
      },
      "position" : {
        "x" : -366.6989609474796,
        "y" : 409.3290715021436
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "208",
        "shared_name" : "IDP T1 FAST ROIs R thalamus",
        "name" : "IDP T1 FAST ROIs R thalamus",
        "SUID" : 208,
        "selected" : false,
        "source_cat" : "regional and tissue volume"
      },
      "position" : {
        "x" : 231.38069877054332,
        "y" : -172.7856787307034
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "206",
        "shared_name" : "IDP dMRI ProbtrackX ICVF mcp",
        "name" : "IDP dMRI ProbtrackX ICVF mcp",
        "SUID" : 206,
        "selected" : false,
        "source_cat" : "WM tract ICVF"
      },
      "position" : {
        "x" : -366.6989609474796,
        "y" : 236.66153002360136
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "190",
        "shared_name" : "aseg rh intensity Pallidum",
        "name" : "aseg rh intensity Pallidum",
        "SUID" : 190,
        "selected" : false,
        "source_cat" : "regional and tissue intensity"
      },
      "position" : {
        "x" : 231.38069877054332,
        "y" : -237.7624925292045
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "1142",
        "source" : "222",
        "target" : "216",
        "abs_rg" : 0.9957158119110434,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0576520910393517,
        "abs_weight" : 0.0576520910393517,
        "Unnamed_0" : 2,
        "shared_name" : "IDP T1 FAST ROIs R caudate (interacts with) IDP T1 FAST ROIs L caudate",
        "rg" : 0.9957158119110434,
        "tce" : 0.75996197145301,
        "name" : "IDP T1 FAST ROIs R caudate (interacts with) IDP T1 FAST ROIs L caudate",
        "interaction" : "interacts with",
        "SUID" : 1142,
        "abs_tce_weight" : 0.75996197145301,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105363,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1140",
        "source" : "222",
        "target" : "214",
        "abs_rg" : 0.2072944068639704,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0189228941747819,
        "abs_weight" : 0.0189228941747819,
        "Unnamed_0" : 3,
        "shared_name" : "IDP T1 FAST ROIs R caudate (interacts with) IDP dMRI TBSS MD Superior longitudinal fasciculus L",
        "rg" : 0.2072944068639704,
        "tce" : 0.554277123561117,
        "name" : "IDP T1 FAST ROIs R caudate (interacts with) IDP dMRI TBSS MD Superior longitudinal fasciculus L",
        "interaction" : "interacts with",
        "SUID" : 1140,
        "abs_tce_weight" : 0.554277123561117,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105385,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1138",
        "source" : "222",
        "target" : "212",
        "abs_rg" : 0.0566468925796174,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : 1,
        "weight" : -0.0134006867225817,
        "abs_weight" : 0.0134006867225817,
        "Unnamed_0" : 4,
        "shared_name" : "IDP T1 FAST ROIs R caudate (interacts with) wg rh intensity-contrast cuneus",
        "rg" : 0.0566468925796174,
        "tce" : -0.118193401014527,
        "name" : "IDP T1 FAST ROIs R caudate (interacts with) wg rh intensity-contrast cuneus",
        "interaction" : "interacts with",
        "SUID" : 1138,
        "abs_tce_weight" : 0.118193401014527,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105389,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1136",
        "source" : "222",
        "target" : "200",
        "abs_rg" : 0.2722409795699068,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0271124735741413,
        "abs_weight" : 0.0271124735741413,
        "Unnamed_0" : 10,
        "shared_name" : "IDP T1 FAST ROIs R caudate (interacts with) IDP dMRI TBSS ICVF Posterior corona radiata R",
        "rg" : -0.2722409795699068,
        "tce" : -0.555090592714482,
        "name" : "IDP T1 FAST ROIs R caudate (interacts with) IDP dMRI TBSS ICVF Posterior corona radiata R",
        "interaction" : "interacts with",
        "SUID" : 1136,
        "abs_tce_weight" : 0.555090592714482,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105393,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1134",
        "source" : "222",
        "target" : "198",
        "abs_rg" : 0.7175850616088278,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0226174945203872,
        "abs_weight" : 0.0226174945203872,
        "Unnamed_0" : 11,
        "shared_name" : "IDP T1 FAST ROIs R caudate (interacts with) IDP T1 FIRST right caudate volume",
        "rg" : 0.7175850616088278,
        "tce" : 0.253146526861288,
        "name" : "IDP T1 FAST ROIs R caudate (interacts with) IDP T1 FIRST right caudate volume",
        "interaction" : "interacts with",
        "SUID" : 1134,
        "abs_tce_weight" : 0.253146526861288,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105397,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1132",
        "source" : "222",
        "target" : "188",
        "abs_rg" : 0.0705258085309302,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0298566440606814,
        "abs_weight" : 0.0298566440606814,
        "Unnamed_0" : 16,
        "shared_name" : "IDP T1 FAST ROIs R caudate (interacts with) BD",
        "rg" : 0.0705258085309302,
        "tce" : 0.22988016543669,
        "name" : "IDP T1 FAST ROIs R caudate (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 1132,
        "abs_tce_weight" : 0.22988016543669,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105401,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1130",
        "source" : "216",
        "target" : "222",
        "abs_rg" : 0.9957158119110434,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.048142010548422,
        "abs_weight" : 0.048142010548422,
        "Unnamed_0" : 51,
        "shared_name" : "IDP T1 FAST ROIs L caudate (interacts with) IDP T1 FAST ROIs R caudate",
        "rg" : 0.9957158119110434,
        "tce" : 0.676651534894102,
        "name" : "IDP T1 FAST ROIs L caudate (interacts with) IDP T1 FAST ROIs R caudate",
        "interaction" : "interacts with",
        "SUID" : 1130,
        "abs_tce_weight" : 0.676651534894102,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105436,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1128",
        "source" : "216",
        "target" : "200",
        "abs_rg" : 0.2830799607436088,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0174904248513584,
        "abs_weight" : 0.0174904248513584,
        "Unnamed_0" : 62,
        "shared_name" : "IDP T1 FAST ROIs L caudate (interacts with) IDP dMRI TBSS ICVF Posterior corona radiata R",
        "rg" : -0.2830799607436088,
        "tce" : -0.438561814034089,
        "name" : "IDP T1 FAST ROIs L caudate (interacts with) IDP dMRI TBSS ICVF Posterior corona radiata R",
        "interaction" : "interacts with",
        "SUID" : 1128,
        "abs_tce_weight" : 0.438561814034089,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105439,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1126",
        "source" : "216",
        "target" : "192",
        "abs_rg" : 0.0592620193813298,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0203697566369382,
        "abs_weight" : 0.0203697566369382,
        "Unnamed_0" : 64,
        "shared_name" : "IDP T1 FAST ROIs L caudate (interacts with) wg rh intensity-contrast parahippocampal",
        "rg" : 0.0592620193813298,
        "tce" : 0.115618746312755,
        "name" : "IDP T1 FAST ROIs L caudate (interacts with) wg rh intensity-contrast parahippocampal",
        "interaction" : "interacts with",
        "SUID" : 1126,
        "abs_tce_weight" : 0.115618746312755,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105442,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1124",
        "source" : "216",
        "target" : "188",
        "abs_rg" : 0.0620078978677121,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0241938572465609,
        "abs_weight" : 0.0241938572465609,
        "Unnamed_0" : 65,
        "shared_name" : "IDP T1 FAST ROIs L caudate (interacts with) BD",
        "rg" : 0.0620078978677121,
        "tce" : 0.191770655570471,
        "name" : "IDP T1 FAST ROIs L caudate (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 1124,
        "abs_tce_weight" : 0.191770655570471,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105445,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1122",
        "source" : "214",
        "target" : "220",
        "abs_rg" : 0.5935576655756798,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0150268728101548,
        "abs_weight" : 0.0150268728101548,
        "Unnamed_0" : 80,
        "shared_name" : "IDP dMRI TBSS MD Superior longitudinal fasciculus L (interacts with) IDP dMRI TBSS MD Anterior limb of internal capsule L",
        "rg" : 0.5935576655756798,
        "tce" : 0.378145282822926,
        "name" : "IDP dMRI TBSS MD Superior longitudinal fasciculus L (interacts with) IDP dMRI TBSS MD Anterior limb of internal capsule L",
        "interaction" : "interacts with",
        "SUID" : 1122,
        "abs_tce_weight" : 0.378145282822926,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105465,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1120",
        "source" : "214",
        "target" : "216",
        "abs_rg" : 0.2253391011209861,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0134335338388308,
        "abs_weight" : 0.0134335338388308,
        "Unnamed_0" : 81,
        "shared_name" : "IDP dMRI TBSS MD Superior longitudinal fasciculus L (interacts with) IDP T1 FAST ROIs L caudate",
        "rg" : 0.2253391011209861,
        "tce" : 0.221329182908183,
        "name" : "IDP dMRI TBSS MD Superior longitudinal fasciculus L (interacts with) IDP T1 FAST ROIs L caudate",
        "interaction" : "interacts with",
        "SUID" : 1120,
        "abs_tce_weight" : 0.221329182908183,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105468,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1118",
        "source" : "214",
        "target" : "200",
        "abs_rg" : 0.8139505956727365,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0360786773761865,
        "abs_weight" : 0.0360786773761865,
        "Unnamed_0" : 88,
        "shared_name" : "IDP dMRI TBSS MD Superior longitudinal fasciculus L (interacts with) IDP dMRI TBSS ICVF Posterior corona radiata R",
        "rg" : -0.8139505956727365,
        "tce" : -0.772215077536152,
        "name" : "IDP dMRI TBSS MD Superior longitudinal fasciculus L (interacts with) IDP dMRI TBSS ICVF Posterior corona radiata R",
        "interaction" : "interacts with",
        "SUID" : 1118,
        "abs_tce_weight" : 0.772215077536152,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105471,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1116",
        "source" : "214",
        "target" : "194",
        "abs_rg" : 0.5389361875346228,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0190423748698942,
        "abs_weight" : 0.0190423748698942,
        "Unnamed_0" : 90,
        "shared_name" : "IDP dMRI TBSS MD Superior longitudinal fasciculus L (interacts with) IDP dMRI TBSS ICVF Cerebral peduncle L",
        "rg" : -0.5389361875346228,
        "tce" : -0.513552440320275,
        "name" : "IDP dMRI TBSS MD Superior longitudinal fasciculus L (interacts with) IDP dMRI TBSS ICVF Cerebral peduncle L",
        "interaction" : "interacts with",
        "SUID" : 1116,
        "abs_tce_weight" : 0.513552440320275,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105474,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1114",
        "source" : "214",
        "target" : "192",
        "abs_rg" : 0.295565756110431,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : 0.020395266886712,
        "abs_weight" : 0.020395266886712,
        "Unnamed_0" : 91,
        "shared_name" : "IDP dMRI TBSS MD Superior longitudinal fasciculus L (interacts with) wg rh intensity-contrast parahippocampal",
        "rg" : -0.295565756110431,
        "tce" : -0.215961802347751,
        "name" : "IDP dMRI TBSS MD Superior longitudinal fasciculus L (interacts with) wg rh intensity-contrast parahippocampal",
        "interaction" : "interacts with",
        "SUID" : 1114,
        "abs_tce_weight" : 0.215961802347751,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105477,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1112",
        "source" : "214",
        "target" : "188",
        "abs_rg" : 0.0700977559759063,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0205989328045127,
        "abs_weight" : 0.0205989328045127,
        "Unnamed_0" : 93,
        "shared_name" : "IDP dMRI TBSS MD Superior longitudinal fasciculus L (interacts with) BD",
        "rg" : 0.0700977559759063,
        "tce" : 0.193095678475342,
        "name" : "IDP dMRI TBSS MD Superior longitudinal fasciculus L (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 1112,
        "abs_tce_weight" : 0.193095678475342,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105480,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1110",
        "source" : "212",
        "target" : "184",
        "abs_rg" : 0.2039197446738717,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0158509550480988,
        "abs_weight" : 0.0158509550480988,
        "Unnamed_0" : 99,
        "shared_name" : "wg rh intensity-contrast cuneus (interacts with) IDP T1 FAST ROIs L cerebellum VIIIa",
        "rg" : 0.2039197446738717,
        "tce" : 0.286596553668253,
        "name" : "wg rh intensity-contrast cuneus (interacts with) IDP T1 FAST ROIs L cerebellum VIIIa",
        "interaction" : "interacts with",
        "SUID" : 1110,
        "abs_tce_weight" : 0.286596553668253,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105484,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1108",
        "source" : "212",
        "target" : "204",
        "abs_rg" : 0.4244819382976109,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0137307324511338,
        "abs_weight" : 0.0137307324511338,
        "Unnamed_0" : 102,
        "shared_name" : "wg rh intensity-contrast cuneus (interacts with) aseg rh intensity Caudate",
        "rg" : -0.4244819382976109,
        "tce" : -0.319828539885773,
        "name" : "wg rh intensity-contrast cuneus (interacts with) aseg rh intensity Caudate",
        "interaction" : "interacts with",
        "SUID" : 1108,
        "abs_tce_weight" : 0.319828539885773,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105488,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1106",
        "source" : "212",
        "target" : "202",
        "abs_rg" : 0.6863454101118679,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0144494631588374,
        "abs_weight" : 0.0144494631588374,
        "Unnamed_0" : 103,
        "shared_name" : "wg rh intensity-contrast cuneus (interacts with) wg rh intensity-contrast paracentral",
        "rg" : 0.6863454101118679,
        "tce" : 0.394278767061195,
        "name" : "wg rh intensity-contrast cuneus (interacts with) wg rh intensity-contrast paracentral",
        "interaction" : "interacts with",
        "SUID" : 1106,
        "abs_tce_weight" : 0.394278767061195,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105492,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1104",
        "source" : "212",
        "target" : "188",
        "abs_rg" : 0.0564948884706339,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.020087332129105,
        "abs_weight" : 0.020087332129105,
        "Unnamed_0" : 108,
        "shared_name" : "wg rh intensity-contrast cuneus (interacts with) BD",
        "rg" : -0.0564948884706339,
        "tce" : -0.109108074709231,
        "name" : "wg rh intensity-contrast cuneus (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 1104,
        "abs_tce_weight" : 0.109108074709231,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105495,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1102",
        "source" : "200",
        "target" : "214",
        "abs_rg" : 0.8139505956727365,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0148791920129293,
        "abs_weight" : 0.0148791920129293,
        "Unnamed_0" : 219,
        "shared_name" : "IDP dMRI TBSS ICVF Posterior corona radiata R (interacts with) IDP dMRI TBSS MD Superior longitudinal fasciculus L",
        "rg" : -0.8139505956727365,
        "tce" : -0.658363647184575,
        "name" : "IDP dMRI TBSS ICVF Posterior corona radiata R (interacts with) IDP dMRI TBSS MD Superior longitudinal fasciculus L",
        "interaction" : "interacts with",
        "SUID" : 1102,
        "abs_tce_weight" : 0.658363647184575,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105595,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1100",
        "source" : "200",
        "target" : "194",
        "abs_rg" : 0.4857150791530735,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0215307270029689,
        "abs_weight" : 0.0215307270029689,
        "Unnamed_0" : 228,
        "shared_name" : "IDP dMRI TBSS ICVF Posterior corona radiata R (interacts with) IDP dMRI TBSS ICVF Cerebral peduncle L",
        "rg" : 0.4857150791530735,
        "tce" : 0.59626027542616,
        "name" : "IDP dMRI TBSS ICVF Posterior corona radiata R (interacts with) IDP dMRI TBSS ICVF Cerebral peduncle L",
        "interaction" : "interacts with",
        "SUID" : 1100,
        "abs_tce_weight" : 0.59626027542616,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105598,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1098",
        "source" : "200",
        "target" : "188",
        "abs_rg" : 0.0812622799472559,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0157724345437637,
        "abs_weight" : 0.0157724345437637,
        "Unnamed_0" : 231,
        "shared_name" : "IDP dMRI TBSS ICVF Posterior corona radiata R (interacts with) BD",
        "rg" : -0.0812622799472559,
        "tce" : -0.15551729562095,
        "name" : "IDP dMRI TBSS ICVF Posterior corona radiata R (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 1098,
        "abs_tce_weight" : 0.15551729562095,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105601,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1096",
        "source" : "198",
        "target" : "222",
        "abs_rg" : 0.7175850616088278,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0196606191951887,
        "abs_weight" : 0.0196606191951887,
        "Unnamed_0" : 232,
        "shared_name" : "IDP T1 FIRST right caudate volume (interacts with) IDP T1 FAST ROIs R caudate",
        "rg" : 0.7175850616088278,
        "tce" : 0.2775787090801,
        "name" : "IDP T1 FIRST right caudate volume (interacts with) IDP T1 FAST ROIs R caudate",
        "interaction" : "interacts with",
        "SUID" : 1096,
        "abs_tce_weight" : 0.2775787090801,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105604,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1094",
        "source" : "198",
        "target" : "216",
        "abs_rg" : 0.717424690654103,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0233722614505552,
        "abs_weight" : 0.0233722614505552,
        "Unnamed_0" : 234,
        "shared_name" : "IDP T1 FIRST right caudate volume (interacts with) IDP T1 FAST ROIs L caudate",
        "rg" : 0.717424690654103,
        "tce" : 0.311092450656235,
        "name" : "IDP T1 FIRST right caudate volume (interacts with) IDP T1 FAST ROIs L caudate",
        "interaction" : "interacts with",
        "SUID" : 1094,
        "abs_tce_weight" : 0.311092450656235,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105607,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1092",
        "source" : "198",
        "target" : "190",
        "abs_rg" : 0.083042630919611,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0183976768866852,
        "abs_weight" : 0.0183976768866852,
        "Unnamed_0" : 242,
        "shared_name" : "IDP T1 FIRST right caudate volume (interacts with) aseg rh intensity Pallidum",
        "rg" : -0.083042630919611,
        "tce" : -0.267110985701682,
        "name" : "IDP T1 FIRST right caudate volume (interacts with) aseg rh intensity Pallidum",
        "interaction" : "interacts with",
        "SUID" : 1092,
        "abs_tce_weight" : 0.267110985701682,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105610,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1090",
        "source" : "198",
        "target" : "188",
        "abs_rg" : 0.0436877328911917,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : 1,
        "weight" : -0.0156704162493868,
        "abs_weight" : 0.0156704162493868,
        "Unnamed_0" : 243,
        "shared_name" : "IDP T1 FIRST right caudate volume (interacts with) BD",
        "rg" : 0.0436877328911917,
        "tce" : -0.0983986398128107,
        "name" : "IDP T1 FIRST right caudate volume (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 1090,
        "abs_tce_weight" : 0.0983986398128107,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105613,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1088",
        "source" : "220",
        "target" : "222",
        "abs_rg" : 0.4620088377363079,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0312754132376618,
        "abs_weight" : 0.0312754132376618,
        "Unnamed_0" : 17,
        "shared_name" : "IDP dMRI TBSS MD Anterior limb of internal capsule L (interacts with) IDP T1 FAST ROIs R caudate",
        "rg" : 0.4620088377363079,
        "tce" : 0.331422322176409,
        "name" : "IDP dMRI TBSS MD Anterior limb of internal capsule L (interacts with) IDP T1 FAST ROIs R caudate",
        "interaction" : "interacts with",
        "SUID" : 1088,
        "abs_tce_weight" : 0.331422322176409,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1086",
        "source" : "220",
        "target" : "216",
        "abs_rg" : 0.5255188397672085,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0297853523944123,
        "abs_weight" : 0.0297853523944123,
        "Unnamed_0" : 19,
        "shared_name" : "IDP dMRI TBSS MD Anterior limb of internal capsule L (interacts with) IDP T1 FAST ROIs L caudate",
        "rg" : 0.5255188397672085,
        "tce" : 0.324506509475639,
        "name" : "IDP dMRI TBSS MD Anterior limb of internal capsule L (interacts with) IDP T1 FAST ROIs L caudate",
        "interaction" : "interacts with",
        "SUID" : 1086,
        "abs_tce_weight" : 0.324506509475639,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105408,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1084",
        "source" : "220",
        "target" : "214",
        "abs_rg" : 0.5935576655756798,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0172708022627589,
        "abs_weight" : 0.0172708022627589,
        "Unnamed_0" : 21,
        "shared_name" : "IDP dMRI TBSS MD Anterior limb of internal capsule L (interacts with) IDP dMRI TBSS MD Superior longitudinal fasciculus L",
        "rg" : 0.5935576655756798,
        "tce" : 0.492238808214218,
        "name" : "IDP dMRI TBSS MD Anterior limb of internal capsule L (interacts with) IDP dMRI TBSS MD Superior longitudinal fasciculus L",
        "interaction" : "interacts with",
        "SUID" : 1084,
        "abs_tce_weight" : 0.492238808214218,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1082",
        "source" : "220",
        "target" : "210",
        "abs_rg" : 0.2205218554735278,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0232971933687824,
        "abs_weight" : 0.0232971933687824,
        "Unnamed_0" : 25,
        "shared_name" : "IDP dMRI TBSS MD Anterior limb of internal capsule L (interacts with) IDP dMRI TBSS OD External capsule R",
        "rg" : -0.2205218554735278,
        "tce" : -0.427804902545206,
        "name" : "IDP dMRI TBSS MD Anterior limb of internal capsule L (interacts with) IDP dMRI TBSS OD External capsule R",
        "interaction" : "interacts with",
        "SUID" : 1082,
        "abs_tce_weight" : 0.427804902545206,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105415,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1080",
        "source" : "220",
        "target" : "198",
        "abs_rg" : 0.288999965060632,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0157913738862749,
        "abs_weight" : 0.0157913738862749,
        "Unnamed_0" : 29,
        "shared_name" : "IDP dMRI TBSS MD Anterior limb of internal capsule L (interacts with) IDP T1 FIRST right caudate volume",
        "rg" : 0.288999965060632,
        "tce" : 0.208891120033196,
        "name" : "IDP dMRI TBSS MD Anterior limb of internal capsule L (interacts with) IDP T1 FIRST right caudate volume",
        "interaction" : "interacts with",
        "SUID" : 1080,
        "abs_tce_weight" : 0.208891120033196,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105418,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1078",
        "source" : "220",
        "target" : "192",
        "abs_rg" : 0.125154712523506,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : -1,
        "weight" : 0.0219150945544097,
        "abs_weight" : 0.0219150945544097,
        "Unnamed_0" : 31,
        "shared_name" : "IDP dMRI TBSS MD Anterior limb of internal capsule L (interacts with) wg rh intensity-contrast parahippocampal",
        "rg" : -0.125154712523506,
        "tce" : 0.122079116250145,
        "name" : "IDP dMRI TBSS MD Anterior limb of internal capsule L (interacts with) wg rh intensity-contrast parahippocampal",
        "interaction" : "interacts with",
        "SUID" : 1078,
        "abs_tce_weight" : 0.122079116250145,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105422,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1076",
        "source" : "220",
        "target" : "188",
        "abs_rg" : 0.0267146153201424,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : 1,
        "weight" : -0.029428636482999,
        "abs_weight" : 0.029428636482999,
        "Unnamed_0" : 32,
        "shared_name" : "IDP dMRI TBSS MD Anterior limb of internal capsule L (interacts with) BD",
        "rg" : 0.0267146153201424,
        "tce" : -0.176323566672909,
        "name" : "IDP dMRI TBSS MD Anterior limb of internal capsule L (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 1076,
        "abs_tce_weight" : 0.176323566672909,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105425,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1074",
        "source" : "210",
        "target" : "186",
        "abs_rg" : 0.1245476590818336,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0160622370840226,
        "abs_weight" : 0.0160622370840226,
        "Unnamed_0" : 138,
        "shared_name" : "IDP dMRI TBSS OD External capsule R (interacts with) AmygNuclei rh volume Lateral-nucleus",
        "rg" : -0.1245476590818336,
        "tce" : -0.186373513180992,
        "name" : "IDP dMRI TBSS OD External capsule R (interacts with) AmygNuclei rh volume Lateral-nucleus",
        "interaction" : "interacts with",
        "SUID" : 1074,
        "abs_tce_weight" : 0.186373513180992,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105508,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1072",
        "source" : "210",
        "target" : "182",
        "abs_rg" : 0.1514668017201754,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0147383084862145,
        "abs_weight" : 0.0147383084862145,
        "Unnamed_0" : 142,
        "shared_name" : "IDP dMRI TBSS OD External capsule R (interacts with) IDP dMRI TBSS OD Cerebral peduncle L",
        "rg" : 0.1514668017201754,
        "tce" : 0.151773155254611,
        "name" : "IDP dMRI TBSS OD External capsule R (interacts with) IDP dMRI TBSS OD Cerebral peduncle L",
        "interaction" : "interacts with",
        "SUID" : 1072,
        "abs_tce_weight" : 0.151773155254611,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105511,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1070",
        "source" : "210",
        "target" : "208",
        "abs_rg" : 0.1507288208963684,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0171674631731898,
        "abs_weight" : 0.0171674631731898,
        "Unnamed_0" : 143,
        "shared_name" : "IDP dMRI TBSS OD External capsule R (interacts with) IDP T1 FAST ROIs R thalamus",
        "rg" : -0.1507288208963684,
        "tce" : -0.207067182614531,
        "name" : "IDP dMRI TBSS OD External capsule R (interacts with) IDP T1 FAST ROIs R thalamus",
        "interaction" : "interacts with",
        "SUID" : 1070,
        "abs_tce_weight" : 0.207067182614531,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105515,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1068",
        "source" : "210",
        "target" : "188",
        "abs_rg" : 0.0040997321968765,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.01859692834061,
        "abs_weight" : 0.01859692834061,
        "Unnamed_0" : 147,
        "shared_name" : "IDP dMRI TBSS OD External capsule R (interacts with) BD",
        "rg" : -0.0040997321968765,
        "tce" : -0.102007230890999,
        "name" : "IDP dMRI TBSS OD External capsule R (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 1068,
        "abs_tce_weight" : 0.102007230890999,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1066",
        "source" : "192",
        "target" : "214",
        "abs_rg" : 0.295565756110431,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : 0.0152269215988942,
        "abs_weight" : 0.0152269215988942,
        "Unnamed_0" : 281,
        "shared_name" : "wg rh intensity-contrast parahippocampal (interacts with) IDP dMRI TBSS MD Superior longitudinal fasciculus L",
        "rg" : -0.295565756110431,
        "tce" : -0.217370917820392,
        "name" : "wg rh intensity-contrast parahippocampal (interacts with) IDP dMRI TBSS MD Superior longitudinal fasciculus L",
        "interaction" : "interacts with",
        "SUID" : 1066,
        "abs_tce_weight" : 0.217370917820392,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105649,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1064",
        "source" : "192",
        "target" : "212",
        "abs_rg" : 0.6420173489869212,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0165740222940666,
        "abs_weight" : 0.0165740222940666,
        "Unnamed_0" : 282,
        "shared_name" : "wg rh intensity-contrast parahippocampal (interacts with) wg rh intensity-contrast cuneus",
        "rg" : 0.6420173489869212,
        "tce" : 0.66154557712753,
        "name" : "wg rh intensity-contrast parahippocampal (interacts with) wg rh intensity-contrast cuneus",
        "interaction" : "interacts with",
        "SUID" : 1064,
        "abs_tce_weight" : 0.66154557712753,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105652,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1062",
        "source" : "192",
        "target" : "202",
        "abs_rg" : 0.5304541891548505,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0188274770226327,
        "abs_weight" : 0.0188274770226327,
        "Unnamed_0" : 288,
        "shared_name" : "wg rh intensity-contrast parahippocampal (interacts with) wg rh intensity-contrast paracentral",
        "rg" : 0.5304541891548505,
        "tce" : 0.72210126481655,
        "name" : "wg rh intensity-contrast parahippocampal (interacts with) wg rh intensity-contrast paracentral",
        "interaction" : "interacts with",
        "SUID" : 1062,
        "abs_tce_weight" : 0.72210126481655,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105655,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1060",
        "source" : "192",
        "target" : "200",
        "abs_rg" : 0.1994284951924655,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : -0.0350233121608305,
        "abs_weight" : 0.0350233121608305,
        "Unnamed_0" : 289,
        "shared_name" : "wg rh intensity-contrast parahippocampal (interacts with) IDP dMRI TBSS ICVF Posterior corona radiata R",
        "rg" : 0.1994284951924655,
        "tce" : 0.157055900147128,
        "name" : "wg rh intensity-contrast parahippocampal (interacts with) IDP dMRI TBSS ICVF Posterior corona radiata R",
        "interaction" : "interacts with",
        "SUID" : 1060,
        "abs_tce_weight" : 0.157055900147128,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105658,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1058",
        "source" : "192",
        "target" : "194",
        "abs_rg" : 0.1015272518930664,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : 1,
        "weight" : -0.0252791191241249,
        "abs_weight" : 0.0252791191241249,
        "Unnamed_0" : 291,
        "shared_name" : "wg rh intensity-contrast parahippocampal (interacts with) IDP dMRI TBSS ICVF Cerebral peduncle L",
        "rg" : 0.1015272518930664,
        "tce" : -0.0987766146580222,
        "name" : "wg rh intensity-contrast parahippocampal (interacts with) IDP dMRI TBSS ICVF Cerebral peduncle L",
        "interaction" : "interacts with",
        "SUID" : 1058,
        "abs_tce_weight" : 0.0987766146580222,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1056",
        "source" : "192",
        "target" : "188",
        "abs_rg" : 0.0599936117043108,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0140207203486641,
        "abs_weight" : 0.0140207203486641,
        "Unnamed_0" : 293,
        "shared_name" : "wg rh intensity-contrast parahippocampal (interacts with) BD",
        "rg" : -0.0599936117043108,
        "tce" : -0.111874719766692,
        "name" : "wg rh intensity-contrast parahippocampal (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 1056,
        "abs_tce_weight" : 0.111874719766692,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105664,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1054",
        "source" : "218",
        "target" : "194",
        "abs_rg" : 0.4594299694044823,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : -0.0220454329312886,
        "abs_weight" : 0.0220454329312886,
        "Unnamed_0" : 47,
        "shared_name" : "IDP dMRI TBSS ICVF Superior cerebellar peduncle R (interacts with) IDP dMRI TBSS ICVF Cerebral peduncle L",
        "rg" : 0.4594299694044823,
        "tce" : 0.0177508055267143,
        "name" : "IDP dMRI TBSS ICVF Superior cerebellar peduncle R (interacts with) IDP dMRI TBSS ICVF Cerebral peduncle L",
        "interaction" : "interacts with",
        "SUID" : 1054,
        "abs_tce_weight" : 0.0177508055267143,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105430,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1052",
        "source" : "218",
        "target" : "188",
        "abs_rg" : 0.0087216307269765,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.025757886590585,
        "abs_weight" : 0.025757886590585,
        "Unnamed_0" : 50,
        "shared_name" : "IDP dMRI TBSS ICVF Superior cerebellar peduncle R (interacts with) BD",
        "rg" : 0.0087216307269765,
        "tce" : 0.138631494637708,
        "name" : "IDP dMRI TBSS ICVF Superior cerebellar peduncle R (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 1052,
        "abs_tce_weight" : 0.138631494637708,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105433,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1050",
        "source" : "194",
        "target" : "220",
        "abs_rg" : 0.3563741136733781,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0183139345836792,
        "abs_weight" : 0.0183139345836792,
        "Unnamed_0" : 259,
        "shared_name" : "IDP dMRI TBSS ICVF Cerebral peduncle L (interacts with) IDP dMRI TBSS MD Anterior limb of internal capsule L",
        "rg" : -0.3563741136733781,
        "tce" : -0.237361906668389,
        "name" : "IDP dMRI TBSS ICVF Cerebral peduncle L (interacts with) IDP dMRI TBSS MD Anterior limb of internal capsule L",
        "interaction" : "interacts with",
        "SUID" : 1050,
        "abs_tce_weight" : 0.237361906668389,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105628,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1048",
        "source" : "194",
        "target" : "218",
        "abs_rg" : 0.4594299694044823,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0410657013844489,
        "abs_weight" : 0.0410657013844489,
        "Unnamed_0" : 260,
        "shared_name" : "IDP dMRI TBSS ICVF Cerebral peduncle L (interacts with) IDP dMRI TBSS ICVF Superior cerebellar peduncle R",
        "rg" : 0.4594299694044823,
        "tce" : 0.339550060894726,
        "name" : "IDP dMRI TBSS ICVF Cerebral peduncle L (interacts with) IDP dMRI TBSS ICVF Superior cerebellar peduncle R",
        "interaction" : "interacts with",
        "SUID" : 1048,
        "abs_tce_weight" : 0.339550060894726,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105631,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1046",
        "source" : "194",
        "target" : "184",
        "abs_rg" : 0.0095911662808677,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : 1,
        "weight" : -0.0146552619928488,
        "abs_weight" : 0.0146552619928488,
        "Unnamed_0" : 265,
        "shared_name" : "IDP dMRI TBSS ICVF Cerebral peduncle L (interacts with) IDP T1 FAST ROIs L cerebellum VIIIa",
        "rg" : 0.0095911662808677,
        "tce" : -0.0812264761248002,
        "name" : "IDP dMRI TBSS ICVF Cerebral peduncle L (interacts with) IDP T1 FAST ROIs L cerebellum VIIIa",
        "interaction" : "interacts with",
        "SUID" : 1046,
        "abs_tce_weight" : 0.0812264761248002,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105634,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1044",
        "source" : "194",
        "target" : "182",
        "abs_rg" : 0.4541469243196995,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0266852090863441,
        "abs_weight" : 0.0266852090863441,
        "Unnamed_0" : 266,
        "shared_name" : "IDP dMRI TBSS ICVF Cerebral peduncle L (interacts with) IDP dMRI TBSS OD Cerebral peduncle L",
        "rg" : 0.4541469243196995,
        "tce" : 0.222736993881862,
        "name" : "IDP dMRI TBSS ICVF Cerebral peduncle L (interacts with) IDP dMRI TBSS OD Cerebral peduncle L",
        "interaction" : "interacts with",
        "SUID" : 1044,
        "abs_tce_weight" : 0.222736993881862,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105637,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1042",
        "source" : "194",
        "target" : "202",
        "abs_rg" : 0.0284090568489853,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : -0.0154515114497705,
        "abs_weight" : 0.0154515114497705,
        "Unnamed_0" : 271,
        "shared_name" : "IDP dMRI TBSS ICVF Cerebral peduncle L (interacts with) wg rh intensity-contrast paracentral",
        "rg" : 0.0284090568489853,
        "tce" : 0.0349517207528618,
        "name" : "IDP dMRI TBSS ICVF Cerebral peduncle L (interacts with) wg rh intensity-contrast paracentral",
        "interaction" : "interacts with",
        "SUID" : 1042,
        "abs_tce_weight" : 0.0349517207528618,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105640,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1040",
        "source" : "194",
        "target" : "190",
        "abs_rg" : 0.002196990077319,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : -1,
        "weight" : 0.041893100450738,
        "abs_weight" : 0.041893100450738,
        "Unnamed_0" : 276,
        "shared_name" : "IDP dMRI TBSS ICVF Cerebral peduncle L (interacts with) aseg rh intensity Pallidum",
        "rg" : -0.002196990077319,
        "tce" : 0.201820988425952,
        "name" : "IDP dMRI TBSS ICVF Cerebral peduncle L (interacts with) aseg rh intensity Pallidum",
        "interaction" : "interacts with",
        "SUID" : 1040,
        "abs_tce_weight" : 0.201820988425952,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105643,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1038",
        "source" : "194",
        "target" : "188",
        "abs_rg" : 0.1438017069019465,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : 1,
        "weight" : -0.0148803217105639,
        "abs_weight" : 0.0148803217105639,
        "Unnamed_0" : 277,
        "shared_name" : "IDP dMRI TBSS ICVF Cerebral peduncle L (interacts with) BD",
        "rg" : 0.1438017069019465,
        "tce" : -0.135715667248557,
        "name" : "IDP dMRI TBSS ICVF Cerebral peduncle L (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 1038,
        "abs_tce_weight" : 0.135715667248557,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105646,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1036",
        "source" : "186",
        "target" : "220",
        "abs_rg" : 0.1212657022292072,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0200068532812874,
        "abs_weight" : 0.0200068532812874,
        "Unnamed_0" : 67,
        "shared_name" : "AmygNuclei rh volume Lateral-nucleus (interacts with) IDP dMRI TBSS MD Anterior limb of internal capsule L",
        "rg" : 0.1212657022292072,
        "tce" : 0.210769899137487,
        "name" : "AmygNuclei rh volume Lateral-nucleus (interacts with) IDP dMRI TBSS MD Anterior limb of internal capsule L",
        "interaction" : "interacts with",
        "SUID" : 1036,
        "abs_tce_weight" : 0.210769899137487,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105449,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1034",
        "source" : "186",
        "target" : "216",
        "abs_rg" : 0.3489426076999297,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0136412063587686,
        "abs_weight" : 0.0136412063587686,
        "Unnamed_0" : 68,
        "shared_name" : "AmygNuclei rh volume Lateral-nucleus (interacts with) IDP T1 FAST ROIs L caudate",
        "rg" : 0.3489426076999297,
        "tce" : 0.169690429314186,
        "name" : "AmygNuclei rh volume Lateral-nucleus (interacts with) IDP T1 FAST ROIs L caudate",
        "interaction" : "interacts with",
        "SUID" : 1034,
        "abs_tce_weight" : 0.169690429314186,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105452,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1032",
        "source" : "186",
        "target" : "196",
        "abs_rg" : 0.4695771561753156,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0160028136658153,
        "abs_weight" : 0.0160028136658153,
        "Unnamed_0" : 75,
        "shared_name" : "AmygNuclei rh volume Lateral-nucleus (interacts with) HippSubfield lh volume Whole-hippocampal-body",
        "rg" : 0.4695771561753156,
        "tce" : 0.186677923034352,
        "name" : "AmygNuclei rh volume Lateral-nucleus (interacts with) HippSubfield lh volume Whole-hippocampal-body",
        "interaction" : "interacts with",
        "SUID" : 1032,
        "abs_tce_weight" : 0.186677923034352,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105456,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1030",
        "source" : "186",
        "target" : "192",
        "abs_rg" : 0.0347326981861135,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0199761540230603,
        "abs_weight" : 0.0199761540230603,
        "Unnamed_0" : 76,
        "shared_name" : "AmygNuclei rh volume Lateral-nucleus (interacts with) wg rh intensity-contrast parahippocampal",
        "rg" : 0.0347326981861135,
        "tce" : 0.172861343747208,
        "name" : "AmygNuclei rh volume Lateral-nucleus (interacts with) wg rh intensity-contrast parahippocampal",
        "interaction" : "interacts with",
        "SUID" : 1030,
        "abs_tce_weight" : 0.172861343747208,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1028",
        "source" : "186",
        "target" : "188",
        "abs_rg" : 0.0270508471446371,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : 1,
        "weight" : -0.0211452411419388,
        "abs_weight" : 0.0211452411419388,
        "Unnamed_0" : 78,
        "shared_name" : "AmygNuclei rh volume Lateral-nucleus (interacts with) BD",
        "rg" : 0.0270508471446371,
        "tce" : -0.124350141873742,
        "name" : "AmygNuclei rh volume Lateral-nucleus (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 1028,
        "abs_tce_weight" : 0.124350141873742,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105462,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1026",
        "source" : "196",
        "target" : "186",
        "abs_rg" : 0.4695771561753156,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0388487422698566,
        "abs_weight" : 0.0388487422698566,
        "Unnamed_0" : 247,
        "shared_name" : "HippSubfield lh volume Whole-hippocampal-body (interacts with) AmygNuclei rh volume Lateral-nucleus",
        "rg" : 0.4695771561753156,
        "tce" : 0.334198305250674,
        "name" : "HippSubfield lh volume Whole-hippocampal-body (interacts with) AmygNuclei rh volume Lateral-nucleus",
        "interaction" : "interacts with",
        "SUID" : 1026,
        "abs_tce_weight" : 0.334198305250674,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105616,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1024",
        "source" : "196",
        "target" : "192",
        "abs_rg" : 0.3330298119401239,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0144713322137073,
        "abs_weight" : 0.0144713322137073,
        "Unnamed_0" : 255,
        "shared_name" : "HippSubfield lh volume Whole-hippocampal-body (interacts with) wg rh intensity-contrast parahippocampal",
        "rg" : 0.3330298119401239,
        "tce" : 0.136885703744005,
        "name" : "HippSubfield lh volume Whole-hippocampal-body (interacts with) wg rh intensity-contrast parahippocampal",
        "interaction" : "interacts with",
        "SUID" : 1024,
        "abs_tce_weight" : 0.136885703744005,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105619,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1022",
        "source" : "196",
        "target" : "190",
        "abs_rg" : 0.015046230150107,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : -1,
        "weight" : 0.0173816716390384,
        "abs_weight" : 0.0173816716390384,
        "Unnamed_0" : 256,
        "shared_name" : "HippSubfield lh volume Whole-hippocampal-body (interacts with) aseg rh intensity Pallidum",
        "rg" : -0.015046230150107,
        "tce" : 0.182305535727314,
        "name" : "HippSubfield lh volume Whole-hippocampal-body (interacts with) aseg rh intensity Pallidum",
        "interaction" : "interacts with",
        "SUID" : 1022,
        "abs_tce_weight" : 0.182305535727314,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105622,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1020",
        "source" : "196",
        "target" : "188",
        "abs_rg" : 0.0248450663545618,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0155440158940452,
        "abs_weight" : 0.0155440158940452,
        "Unnamed_0" : 257,
        "shared_name" : "HippSubfield lh volume Whole-hippocampal-body (interacts with) BD",
        "rg" : 0.0248450663545618,
        "tce" : 0.0984543034763264,
        "name" : "HippSubfield lh volume Whole-hippocampal-body (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 1020,
        "abs_tce_weight" : 0.0984543034763264,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105625,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1018",
        "source" : "184",
        "target" : "188",
        "abs_rg" : 0.0030288498774124,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : -1,
        "weight" : 0.0196749951937848,
        "abs_weight" : 0.0196749951937848,
        "Unnamed_0" : 120,
        "shared_name" : "IDP T1 FAST ROIs L cerebellum VIIIa (interacts with) BD",
        "rg" : -0.0030288498774124,
        "tce" : 0.114490905499269,
        "name" : "IDP T1 FAST ROIs L cerebellum VIIIa (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 1018,
        "abs_tce_weight" : 0.114490905499269,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105498,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1016",
        "source" : "204",
        "target" : "222",
        "abs_rg" : 0.3847958562630375,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0289179084248071,
        "abs_weight" : 0.0289179084248071,
        "Unnamed_0" : 181,
        "shared_name" : "aseg rh intensity Caudate (interacts with) IDP T1 FAST ROIs R caudate",
        "rg" : -0.3847958562630375,
        "tce" : -0.520577773195737,
        "name" : "aseg rh intensity Caudate (interacts with) IDP T1 FAST ROIs R caudate",
        "interaction" : "interacts with",
        "SUID" : 1016,
        "abs_tce_weight" : 0.520577773195737,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105558,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1014",
        "source" : "204",
        "target" : "216",
        "abs_rg" : 0.362401984281176,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.032903201796419,
        "abs_weight" : 0.032903201796419,
        "Unnamed_0" : 184,
        "shared_name" : "aseg rh intensity Caudate (interacts with) IDP T1 FAST ROIs L caudate",
        "rg" : -0.362401984281176,
        "tce" : -0.574372011969803,
        "name" : "aseg rh intensity Caudate (interacts with) IDP T1 FAST ROIs L caudate",
        "interaction" : "interacts with",
        "SUID" : 1014,
        "abs_tce_weight" : 0.574372011969803,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105561,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1012",
        "source" : "204",
        "target" : "208",
        "abs_rg" : 0.2542123804811954,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0154351068377166,
        "abs_weight" : 0.0154351068377166,
        "Unnamed_0" : 189,
        "shared_name" : "aseg rh intensity Caudate (interacts with) IDP T1 FAST ROIs R thalamus",
        "rg" : -0.2542123804811954,
        "tce" : -0.182492035030067,
        "name" : "aseg rh intensity Caudate (interacts with) IDP T1 FAST ROIs R thalamus",
        "interaction" : "interacts with",
        "SUID" : 1012,
        "abs_tce_weight" : 0.182492035030067,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105564,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1010",
        "source" : "204",
        "target" : "206",
        "abs_rg" : 0.1169704286524035,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.017028484727278,
        "abs_weight" : 0.017028484727278,
        "Unnamed_0" : 190,
        "shared_name" : "aseg rh intensity Caudate (interacts with) IDP dMRI ProbtrackX ICVF mcp",
        "rg" : -0.1169704286524035,
        "tce" : -0.105669806088881,
        "name" : "aseg rh intensity Caudate (interacts with) IDP dMRI ProbtrackX ICVF mcp",
        "interaction" : "interacts with",
        "SUID" : 1010,
        "abs_tce_weight" : 0.105669806088881,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105567,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1008",
        "source" : "204",
        "target" : "200",
        "abs_rg" : 0.033133644146392,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : -1,
        "weight" : -0.0134051799162557,
        "abs_weight" : 0.0134051799162557,
        "Unnamed_0" : 192,
        "shared_name" : "aseg rh intensity Caudate (interacts with) IDP dMRI TBSS ICVF Posterior corona radiata R",
        "rg" : -0.033133644146392,
        "tce" : 0.0729401767106809,
        "name" : "aseg rh intensity Caudate (interacts with) IDP dMRI TBSS ICVF Posterior corona radiata R",
        "interaction" : "interacts with",
        "SUID" : 1008,
        "abs_tce_weight" : 0.0729401767106809,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105570,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1006",
        "source" : "204",
        "target" : "198",
        "abs_rg" : 0.0212317451681794,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0291138947769477,
        "abs_weight" : 0.0291138947769477,
        "Unnamed_0" : 193,
        "shared_name" : "aseg rh intensity Caudate (interacts with) IDP T1 FIRST right caudate volume",
        "rg" : -0.0212317451681794,
        "tce" : -0.285890782466412,
        "name" : "aseg rh intensity Caudate (interacts with) IDP T1 FIRST right caudate volume",
        "interaction" : "interacts with",
        "SUID" : 1006,
        "abs_tce_weight" : 0.285890782466412,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105573,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1004",
        "source" : "204",
        "target" : "190",
        "abs_rg" : 0.3490271496696293,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0307240527762302,
        "abs_weight" : 0.0307240527762302,
        "Unnamed_0" : 196,
        "shared_name" : "aseg rh intensity Caudate (interacts with) aseg rh intensity Pallidum",
        "rg" : 0.3490271496696293,
        "tce" : 0.349871204284544,
        "name" : "aseg rh intensity Caudate (interacts with) aseg rh intensity Pallidum",
        "interaction" : "interacts with",
        "SUID" : 1004,
        "abs_tce_weight" : 0.349871204284544,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105577,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1002",
        "source" : "204",
        "target" : "188",
        "abs_rg" : 0.0068343860779781,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : 1,
        "weight" : -0.0173601454208131,
        "abs_weight" : 0.0173601454208131,
        "Unnamed_0" : 197,
        "shared_name" : "aseg rh intensity Caudate (interacts with) BD",
        "rg" : 0.0068343860779781,
        "tce" : -0.115447258745751,
        "name" : "aseg rh intensity Caudate (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 1002,
        "abs_tce_weight" : 0.115447258745751,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1000",
        "source" : "202",
        "target" : "212",
        "abs_rg" : 0.6863454101118679,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0156158362055448,
        "abs_weight" : 0.0156158362055448,
        "Unnamed_0" : 203,
        "shared_name" : "wg rh intensity-contrast paracentral (interacts with) wg rh intensity-contrast cuneus",
        "rg" : 0.6863454101118679,
        "tce" : 0.549089052925516,
        "name" : "wg rh intensity-contrast paracentral (interacts with) wg rh intensity-contrast cuneus",
        "interaction" : "interacts with",
        "SUID" : 1000,
        "abs_tce_weight" : 0.549089052925516,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105583,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "998",
        "source" : "202",
        "target" : "182",
        "abs_rg" : 0.0299804566914943,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0152124175816568,
        "abs_weight" : 0.0152124175816568,
        "Unnamed_0" : 205,
        "shared_name" : "wg rh intensity-contrast paracentral (interacts with) IDP dMRI TBSS OD Cerebral peduncle L",
        "rg" : 0.0299804566914943,
        "tce" : 0.353485747030456,
        "name" : "wg rh intensity-contrast paracentral (interacts with) IDP dMRI TBSS OD Cerebral peduncle L",
        "interaction" : "interacts with",
        "SUID" : 998,
        "abs_tce_weight" : 0.353485747030456,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105586,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "996",
        "source" : "202",
        "target" : "210",
        "abs_rg" : 0.1376928554032928,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0278749617007972,
        "abs_weight" : 0.0278749617007972,
        "Unnamed_0" : 206,
        "shared_name" : "wg rh intensity-contrast paracentral (interacts with) IDP dMRI TBSS OD External capsule R",
        "rg" : 0.1376928554032928,
        "tce" : 0.41882690448054,
        "name" : "wg rh intensity-contrast paracentral (interacts with) IDP dMRI TBSS OD External capsule R",
        "interaction" : "interacts with",
        "SUID" : 996,
        "abs_tce_weight" : 0.41882690448054,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105589,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "994",
        "source" : "202",
        "target" : "188",
        "abs_rg" : 0.0607377414357946,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0161525964767689,
        "abs_weight" : 0.0161525964767689,
        "Unnamed_0" : 215,
        "shared_name" : "wg rh intensity-contrast paracentral (interacts with) BD",
        "rg" : -0.0607377414357946,
        "tce" : -0.132861242546723,
        "name" : "wg rh intensity-contrast paracentral (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 994,
        "abs_tce_weight" : 0.132861242546723,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105592,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "992",
        "source" : "182",
        "target" : "200",
        "abs_rg" : 0.0275915248673252,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0138967709407629,
        "abs_weight" : 0.0138967709407629,
        "Unnamed_0" : 131,
        "shared_name" : "IDP dMRI TBSS OD Cerebral peduncle L (interacts with) IDP dMRI TBSS ICVF Posterior corona radiata R",
        "rg" : -0.0275915248673252,
        "tce" : -0.144347992092576,
        "name" : "IDP dMRI TBSS OD Cerebral peduncle L (interacts with) IDP dMRI TBSS ICVF Posterior corona radiata R",
        "interaction" : "interacts with",
        "SUID" : 992,
        "abs_tce_weight" : 0.144347992092576,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105502,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "990",
        "source" : "182",
        "target" : "188",
        "abs_rg" : 0.0545981456168023,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0194301005833657,
        "abs_weight" : 0.0194301005833657,
        "Unnamed_0" : 134,
        "shared_name" : "IDP dMRI TBSS OD Cerebral peduncle L (interacts with) BD",
        "rg" : 0.0545981456168023,
        "tce" : 0.125441245160833,
        "name" : "IDP dMRI TBSS OD Cerebral peduncle L (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 990,
        "abs_tce_weight" : 0.125441245160833,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105505,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "988",
        "source" : "208",
        "target" : "222",
        "abs_rg" : 0.1882118940740176,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0268552260552602,
        "abs_weight" : 0.0268552260552602,
        "Unnamed_0" : 148,
        "shared_name" : "IDP T1 FAST ROIs R thalamus (interacts with) IDP T1 FAST ROIs R caudate",
        "rg" : 0.1882118940740176,
        "tce" : 0.324798017523945,
        "name" : "IDP T1 FAST ROIs R thalamus (interacts with) IDP T1 FAST ROIs R caudate",
        "interaction" : "interacts with",
        "SUID" : 988,
        "abs_tce_weight" : 0.324798017523945,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105521,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "986",
        "source" : "208",
        "target" : "220",
        "abs_rg" : 0.0760799304019844,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0137521407869029,
        "abs_weight" : 0.0137521407869029,
        "Unnamed_0" : 149,
        "shared_name" : "IDP T1 FAST ROIs R thalamus (interacts with) IDP dMRI TBSS MD Anterior limb of internal capsule L",
        "rg" : 0.0760799304019844,
        "tce" : 0.211596429348468,
        "name" : "IDP T1 FAST ROIs R thalamus (interacts with) IDP dMRI TBSS MD Anterior limb of internal capsule L",
        "interaction" : "interacts with",
        "SUID" : 986,
        "abs_tce_weight" : 0.211596429348468,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105524,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "984",
        "source" : "208",
        "target" : "216",
        "abs_rg" : 0.2036788378340223,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0268731226525245,
        "abs_weight" : 0.0268731226525245,
        "Unnamed_0" : 151,
        "shared_name" : "IDP T1 FAST ROIs R thalamus (interacts with) IDP T1 FAST ROIs L caudate",
        "rg" : 0.2036788378340223,
        "tce" : 0.388290265873958,
        "name" : "IDP T1 FAST ROIs R thalamus (interacts with) IDP T1 FAST ROIs L caudate",
        "interaction" : "interacts with",
        "SUID" : 984,
        "abs_tce_weight" : 0.388290265873958,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105527,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "982",
        "source" : "208",
        "target" : "204",
        "abs_rg" : 0.2542123804811954,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0191229390527016,
        "abs_weight" : 0.0191229390527016,
        "Unnamed_0" : 157,
        "shared_name" : "IDP T1 FAST ROIs R thalamus (interacts with) aseg rh intensity Caudate",
        "rg" : -0.2542123804811954,
        "tce" : -0.245663472482422,
        "name" : "IDP T1 FAST ROIs R thalamus (interacts with) aseg rh intensity Caudate",
        "interaction" : "interacts with",
        "SUID" : 982,
        "abs_tce_weight" : 0.245663472482422,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105530,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "980",
        "source" : "208",
        "target" : "188",
        "abs_rg" : 0.0135029860947925,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : -1,
        "weight" : 0.0175287280847684,
        "abs_weight" : 0.0175287280847684,
        "Unnamed_0" : 163,
        "shared_name" : "IDP T1 FAST ROIs R thalamus (interacts with) BD",
        "rg" : -0.0135029860947925,
        "tce" : 0.11671531887103,
        "name" : "IDP T1 FAST ROIs R thalamus (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 980,
        "abs_tce_weight" : 0.11671531887103,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105533,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "978",
        "source" : "206",
        "target" : "220",
        "abs_rg" : 0.3772202071794638,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0204004180415949,
        "abs_weight" : 0.0204004180415949,
        "Unnamed_0" : 165,
        "shared_name" : "IDP dMRI ProbtrackX ICVF mcp (interacts with) IDP dMRI TBSS MD Anterior limb of internal capsule L",
        "rg" : -0.3772202071794638,
        "tce" : -0.366570958743282,
        "name" : "IDP dMRI ProbtrackX ICVF mcp (interacts with) IDP dMRI TBSS MD Anterior limb of internal capsule L",
        "interaction" : "interacts with",
        "SUID" : 978,
        "abs_tce_weight" : 0.366570958743282,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105537,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "976",
        "source" : "206",
        "target" : "218",
        "abs_rg" : 0.5863387497637607,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0431458398736346,
        "abs_weight" : 0.0431458398736346,
        "Unnamed_0" : 166,
        "shared_name" : "IDP dMRI ProbtrackX ICVF mcp (interacts with) IDP dMRI TBSS ICVF Superior cerebellar peduncle R",
        "rg" : 0.5863387497637607,
        "tce" : 0.544724813327642,
        "name" : "IDP dMRI ProbtrackX ICVF mcp (interacts with) IDP dMRI TBSS ICVF Superior cerebellar peduncle R",
        "interaction" : "interacts with",
        "SUID" : 976,
        "abs_tce_weight" : 0.544724813327642,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105540,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "974",
        "source" : "206",
        "target" : "186",
        "abs_rg" : 0.0586832942320181,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : -1,
        "weight" : 0.017548418098255,
        "abs_weight" : 0.017548418098255,
        "Unnamed_0" : 168,
        "shared_name" : "IDP dMRI ProbtrackX ICVF mcp (interacts with) AmygNuclei rh volume Lateral-nucleus",
        "rg" : -0.0586832942320181,
        "tce" : 0.108658835182771,
        "name" : "IDP dMRI ProbtrackX ICVF mcp (interacts with) AmygNuclei rh volume Lateral-nucleus",
        "interaction" : "interacts with",
        "SUID" : 974,
        "abs_tce_weight" : 0.108658835182771,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105543,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "972",
        "source" : "206",
        "target" : "214",
        "abs_rg" : 0.5626118763308727,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0260355626763832,
        "abs_weight" : 0.0260355626763832,
        "Unnamed_0" : 169,
        "shared_name" : "IDP dMRI ProbtrackX ICVF mcp (interacts with) IDP dMRI TBSS MD Superior longitudinal fasciculus L",
        "rg" : -0.5626118763308727,
        "tce" : -0.655806630892992,
        "name" : "IDP dMRI ProbtrackX ICVF mcp (interacts with) IDP dMRI TBSS MD Superior longitudinal fasciculus L",
        "interaction" : "interacts with",
        "SUID" : 972,
        "abs_tce_weight" : 0.655806630892992,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105546,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "970",
        "source" : "206",
        "target" : "200",
        "abs_rg" : 0.5705929096826223,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0258486434834867,
        "abs_weight" : 0.0258486434834867,
        "Unnamed_0" : 174,
        "shared_name" : "IDP dMRI ProbtrackX ICVF mcp (interacts with) IDP dMRI TBSS ICVF Posterior corona radiata R",
        "rg" : 0.5705929096826223,
        "tce" : 0.613125391777802,
        "name" : "IDP dMRI ProbtrackX ICVF mcp (interacts with) IDP dMRI TBSS ICVF Posterior corona radiata R",
        "interaction" : "interacts with",
        "SUID" : 970,
        "abs_tce_weight" : 0.613125391777802,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105549,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "968",
        "source" : "206",
        "target" : "194",
        "abs_rg" : 0.6026962484956111,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0239059846002606,
        "abs_weight" : 0.0239059846002606,
        "Unnamed_0" : 177,
        "shared_name" : "IDP dMRI ProbtrackX ICVF mcp (interacts with) IDP dMRI TBSS ICVF Cerebral peduncle L",
        "rg" : 0.6026962484956111,
        "tce" : 0.600099952699891,
        "name" : "IDP dMRI ProbtrackX ICVF mcp (interacts with) IDP dMRI TBSS ICVF Cerebral peduncle L",
        "interaction" : "interacts with",
        "SUID" : 968,
        "abs_tce_weight" : 0.600099952699891,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105552,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "966",
        "source" : "206",
        "target" : "188",
        "abs_rg" : 0.0257883444822933,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : 1,
        "weight" : -0.0175197333232332,
        "abs_weight" : 0.0175197333232332,
        "Unnamed_0" : 180,
        "shared_name" : "IDP dMRI ProbtrackX ICVF mcp (interacts with) BD",
        "rg" : 0.0257883444822933,
        "tce" : -0.153013096180089,
        "name" : "IDP dMRI ProbtrackX ICVF mcp (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 966,
        "abs_tce_weight" : 0.153013096180089,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105555,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "964",
        "source" : "190",
        "target" : "220",
        "abs_rg" : 0.2494748808832325,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : -1,
        "weight" : 0.017346388942971,
        "abs_weight" : 0.017346388942971,
        "Unnamed_0" : 294,
        "shared_name" : "aseg rh intensity Pallidum (interacts with) IDP dMRI TBSS MD Anterior limb of internal capsule L",
        "rg" : -0.2494748808832325,
        "tce" : 0.0808174179946362,
        "name" : "aseg rh intensity Pallidum (interacts with) IDP dMRI TBSS MD Anterior limb of internal capsule L",
        "interaction" : "interacts with",
        "SUID" : 964,
        "abs_tce_weight" : 0.0808174179946362,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "962",
        "source" : "190",
        "target" : "218",
        "abs_rg" : 0.0476278562677172,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : 1,
        "weight" : -0.021770566389384,
        "abs_weight" : 0.021770566389384,
        "Unnamed_0" : 295,
        "shared_name" : "aseg rh intensity Pallidum (interacts with) IDP dMRI TBSS ICVF Superior cerebellar peduncle R",
        "rg" : 0.0476278562677172,
        "tce" : -0.108503822485927,
        "name" : "aseg rh intensity Pallidum (interacts with) IDP dMRI TBSS ICVF Superior cerebellar peduncle R",
        "interaction" : "interacts with",
        "SUID" : 962,
        "abs_tce_weight" : 0.108503822485927,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105670,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "960",
        "source" : "190",
        "target" : "184",
        "abs_rg" : 0.1364384491616977,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0146837868181549,
        "abs_weight" : 0.0146837868181549,
        "Unnamed_0" : 299,
        "shared_name" : "aseg rh intensity Pallidum (interacts with) IDP T1 FAST ROIs L cerebellum VIIIa",
        "rg" : -0.1364384491616977,
        "tce" : -0.231583961314707,
        "name" : "aseg rh intensity Pallidum (interacts with) IDP T1 FAST ROIs L cerebellum VIIIa",
        "interaction" : "interacts with",
        "SUID" : 960,
        "abs_tce_weight" : 0.231583961314707,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105673,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "958",
        "source" : "190",
        "target" : "204",
        "abs_rg" : 0.3490271496696293,
        "shared_interaction" : "interacts with",
        "sign_tce" : 1,
        "sign" : 1,
        "weight" : 0.0223132163910624,
        "abs_weight" : 0.0223132163910624,
        "Unnamed_0" : 304,
        "shared_name" : "aseg rh intensity Pallidum (interacts with) aseg rh intensity Caudate",
        "rg" : 0.3490271496696293,
        "tce" : 0.332023329006162,
        "name" : "aseg rh intensity Pallidum (interacts with) aseg rh intensity Caudate",
        "interaction" : "interacts with",
        "SUID" : 958,
        "abs_tce_weight" : 0.332023329006162,
        "rg_sign" : 1,
        "BEND_MAP_ID" : 105676,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "956",
        "source" : "190",
        "target" : "194",
        "abs_rg" : 0.002196990077319,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0252420983234328,
        "abs_weight" : 0.0252420983234328,
        "Unnamed_0" : 307,
        "shared_name" : "aseg rh intensity Pallidum (interacts with) IDP dMRI TBSS ICVF Cerebral peduncle L",
        "rg" : -0.002196990077319,
        "tce" : -0.196018195931603,
        "name" : "aseg rh intensity Pallidum (interacts with) IDP dMRI TBSS ICVF Cerebral peduncle L",
        "interaction" : "interacts with",
        "SUID" : 956,
        "abs_tce_weight" : 0.196018195931603,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105679,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "954",
        "source" : "190",
        "target" : "188",
        "abs_rg" : 0.0210434717114362,
        "shared_interaction" : "interacts with",
        "sign_tce" : -1,
        "sign" : -1,
        "weight" : -0.0139619963134844,
        "abs_weight" : 0.0139619963134844,
        "Unnamed_0" : 308,
        "shared_name" : "aseg rh intensity Pallidum (interacts with) BD",
        "rg" : -0.0210434717114362,
        "tce" : -0.106913292430782,
        "name" : "aseg rh intensity Pallidum (interacts with) BD",
        "interaction" : "interacts with",
        "SUID" : 954,
        "abs_tce_weight" : 0.106913292430782,
        "rg_sign" : -1,
        "BEND_MAP_ID" : 105682,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}